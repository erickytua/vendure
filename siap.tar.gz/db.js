const { createClient } = require('redis');
const crypto = require('crypto');
const path = require('path');

// Build Redis options from environment variables if present, otherwise fall back to defaults
function _buildRedisOptions(override) {
    const host = process.env.REDIS_HOST || 'redis-10092.c52.us-east-1-4.ec2.cloud.redislabs.com';
    const port = Number(process.env.REDIS_PORT || 10092);
    const username = process.env.REDIS_USERNAME || 'default';
    const password = process.env.REDIS_PASSWORD || 'xTcF2J1F1VoPiwyg9CBcc4fzYMG4IP4W';
    const tls = (String(process.env.REDIS_TLS || '').toLowerCase() === 'true');
    const socket = { host, port };
    if (tls) socket.tls = true;
    const opt = { username, password, socket };
    return Object.assign({}, opt, override || {});
}

let client = null;
let usersCache = []; // in-memory snapshot of users to preserve synchronous reads
let bankCache = { total: 0, updatedAt: new Date().toISOString() };
let pvpCache = new Map(); // code -> room object (in-memory cache for sync reads)

function _safeParseJSON(v) {
    try { return JSON.parse(v); } catch (e) { return null; }
}

async function init(redisOptions) {
    if (client) return;
    // Support legacy call DB.init(pathToSqlite) by ignoring string arg
    if (typeof redisOptions === 'string') redisOptions = undefined;
    const opts = _buildRedisOptions(redisOptions);
    client = createClient(opts);
    client.on('error', err => console.error('Redis Client Error', err));
    await client.connect();

    // Load initial caches
    try {
        const rawUsers = await client.hVals('users');
        usersCache = rawUsers.map(r => _safeParseJSON(r)).filter(Boolean);
    } catch (e) {
        console.error('Failed to load users from Redis:', e);
        usersCache = [];
    }
    try {
        const total = await client.get('bank:total');
        const updatedAt = await client.get('bank:updatedAt');
        bankCache = { total: Number(total || 0), updatedAt: updatedAt || new Date().toISOString() };
    } catch (e) {
        console.error('Failed to load bank from Redis:', e);
        bankCache = { total: 0, updatedAt: new Date().toISOString() };
    }
    // Load PVP rooms into in-memory cache
    try {
        const codes = await client.sMembers('pvp:rooms');
        if (Array.isArray(codes) && codes.length) {
            const vals = await Promise.all(codes.map(c => client.get(_pvpKey(c)).catch(() => null)));
            for (let i = 0; i < codes.length; i++) {
                try {
                    const raw = vals[i];
                    const obj = raw ? _safeParseJSON(raw) : null;
                    if (obj) pvpCache.set(codes[i], obj);
                } catch (e) { /* ignore individual */ }
            }
        }
    } catch (e) { /* ignore */ }
}

function getAllUsers() {
    // Return a shallow copy to avoid external mutation of our cache
    return usersCache.slice();
}

function replaceAllUsers(users) {
    // Update cache synchronously and persist asynchronously
    usersCache = (users || []).map(u => ({ number: String(u.number), uid: u.uid || null, addedBy: u.addedBy || null, addedAt: u.addedAt || new Date().toISOString(), balance: Number(u.balance || 0) }));
    // Fire-and-forget: persist replacement to Redis
    (async () => {
        try {
            if (!client) return;
            const multi = client.multi();
            multi.del('users');
            if (usersCache.length) {
                const args = [];
                for (const u of usersCache) args.push(u.number, JSON.stringify(u));
                multi.hSet('users', args);
            }
            await multi.exec();
        } catch (e) {
            console.error('replaceAllUsers persist error:', e);
        }
    })();
}

function getBank() {
    return { total: Number(bankCache.total || 0), updatedAt: bankCache.updatedAt };
}

function setBank(total) {
    bankCache.total = Number(total || 0);
    bankCache.updatedAt = new Date().toISOString();
    // Persist asynchronously
    (async () => {
        try {
            if (!client) return;
            await client.set('bank:total', String(bankCache.total));
            await client.set('bank:updatedAt', bankCache.updatedAt);
        } catch (e) { console.error('setBank persist error:', e); }
    })();
    return getBank();
}

function addToBank(amount) {
    const amt = Number(amount || 0);
    // Update cache locally and persist via INCRBY
    bankCache.total = Number(bankCache.total || 0) + amt;
    bankCache.updatedAt = new Date().toISOString();
    (async () => {
        try {
            if (!client) return;
            await client.incrBy('bank:total', amt);
            await client.set('bank:updatedAt', bankCache.updatedAt);
        } catch (e) { console.error('addToBank persist error:', e); }
    })();
    return bankCache.total;
}

function addHistoryTf(entry) {
    // Disabled: do not persist history_tf to Redis per configuration request
    return;
}

function getHistoryTf(limit = 100) {
    // history_tf persistence disabled; return empty
    return [];
}

function clearHistoryTf() {
    // No-op: history not persisted
    return;
}

// --- PVP helpers using Redis ---
function _pvpKey(code) { return `pvp:room:${code}`; }

async function savePvpRoomRedis(room) {
    if (!room || !room.code) return;
    try {
        // persist to Redis and update cache
        if (client) {
            const key = _pvpKey(room.code);
            await client.set(key, JSON.stringify(room));
            await client.sAdd('pvp:rooms', room.code);
        }
        pvpCache.set(String(room.code), room);
    } catch (e) { console.error('savePvpRoomRedis error:', e); }
}

async function loadPvpRoomRedis(code) {
    if (!code) return null;
    try {
        // Try Redis first
        if (client) {
            const raw = await client.get(_pvpKey(code));
            if (raw) {
                const obj = _safeParseJSON(raw);
                if (obj) { pvpCache.set(String(code), obj); return obj; }
            }
        }
        // Fallback to in-memory cache
        return pvpCache.has(String(code)) ? pvpCache.get(String(code)) : null;
    } catch (e) { console.error('loadPvpRoomRedis error:', e); return null; }
}

async function deletePvpRoomRedis(code) {
    if (!code) return;
    try {
        if (client) {
            await client.del(_pvpKey(code));
            await client.sRem('pvp:rooms', code);
        }
        pvpCache.delete(String(code));
    } catch (e) { console.error('deletePvpRoomRedis error:', e); }
}

async function listPvpRoomsRedis() {
    try {
        if (client) {
            const codes = await client.sMembers('pvp:rooms');
            if (Array.isArray(codes) && codes.length) {
                const vals = await Promise.all(codes.map(c => client.get(_pvpKey(c)).catch(() => null)));
                const out = [];
                for (let i = 0; i < codes.length; i++) {
                    const raw = vals[i];
                    if (!raw) continue;
                    const obj = _safeParseJSON(raw);
                    if (obj) out.push(obj);
                }
                return out;
            }
        }
        return Array.from(pvpCache.values());
    } catch (e) { console.error('listPvpRoomsRedis error:', e); return Array.from(pvpCache.values()); }
}

async function findPvpRoomByParticipantRedis(number) {
    try {
        const rooms = await listPvpRoomsRedis();
        return rooms.find(r => Array.isArray(r.participants) && r.participants.some(p => p && p.number === number)) || null;
    } catch (e) { return null; }
}

async function findPvpRoomByCreatorRedis(number) {
    try {
        const rooms = await listPvpRoomsRedis();
        return rooms.find(r => r && r.creator === number) || null;
    } catch (e) { return null; }
}

function getWarns() {
    // Return synchronous copy of warns (best-effort)
    if (!client) return {};
    // We will attempt to fetch warns synchronously is not possible; instead provide a Promise-returning variant when needed.
    // For compatibility, return empty object and recommend using getWarnsAsync if caller needs fresh data.
    return {};
}

async function getWarnsAsync() {
    if (!client) return {};
    try {
        const rows = await client.hGetAll('warns');
        const out = {};
        for (const k of Object.keys(rows || {})) out[k] = Number(rows[k] || 0);
        return out;
    } catch (e) { console.error('getWarnsAsync error:', e); return {}; }
}

function setWarn(number, count) {
    // Update asynchronously
    (async () => { try { if (!client) return; await client.hSet('warns', String(number), String(Number(count || 0))); } catch (e) { console.error('setWarn error:', e); } })();
}

// Distributed lock helpers for withRegistrationsLock
async function _acquireLock(lockKey, token, ttl = 5000, retries = 50, delay = 100) {
    for (let i = 0; i < retries; i++) {
        try {
            const ok = await client.set(lockKey, token, { NX: true, PX: ttl });
            if (ok) return true;
        } catch (e) { /* ignore */ }
        await new Promise(r => setTimeout(r, delay));
    }
    return false;
}

async function _releaseLock(lockKey, token) {
    // Use Lua to release only if token matches
    const lua = `if redis.call("get", KEYS[1]) == ARGV[1] then return redis.call("del", KEYS[1]) else return 0 end`;
    try {
        await client.eval(lua, { keys: [lockKey], arguments: [token] });
    } catch (e) { /* ignore */ }
}

function withRegistrationsLock(fn) {
    // Keep an in-process queue to avoid concurrent callers in same process
    if (!withRegistrationsLock._queue) withRegistrationsLock._queue = Promise.resolve();
    withRegistrationsLock._queue = withRegistrationsLock._queue.then(async () => {
        const lockKey = 'lock:registrations';
        const token = crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex');
        try {
            const acquired = client ? await _acquireLock(lockKey, token, 5000, 50, 100) : true;
            const regsNow = getAllUsers();
            const res = await Promise.resolve().then(() => fn(regsNow));
            // Persist regsNow to Redis (atomic replacement)
            if (client) {
                const multi = client.multi();
                multi.del('users');
                if (Array.isArray(regsNow) && regsNow.length) {
                    const args = [];
                    for (const u of regsNow) args.push(String(u.number), JSON.stringify(u));
                    multi.hSet('users', args);
                }
                await multi.exec();
            }
            // Update in-memory cache
            usersCache = Array.isArray(regsNow) ? regsNow.slice() : [];
            return res;
        } catch (e) {
            console.error('DB withRegistrationsLock error:', e);
        } finally {
            if (client) await _releaseLock('lock:registrations', token);
        }
    }).catch(e => { console.error('withRegistrationsLock queue error:', e); });
    return withRegistrationsLock._queue;
}

// Atomic transfer implemented with a Redis Lua script to avoid full users
// replacement and heavy locking. Returns { senderBalance, targetBalance }
async function atomicTransfer(senderNumber, targetNumber, amount, fee) {
    if (!client) {
        // Fallback: perform via withRegistrationsLock (slower)
        return withRegistrationsLock(async (regsNow) => {
            const s = regsNow.find(r => r.number === senderNumber);
            const t = regsNow.find(r => r.number === targetNumber);
            if (!s || !t) return null;
            const total = Number(amount || 0) + Number(fee || 0);
            if (Number(s.balance || 0) < total) return null;
            s.balance = Number(s.balance || 0) - total;
            t.balance = Number(t.balance || 0) + Number(amount || 0);
            return { senderBalance: Number(s.balance || 0), targetBalance: Number(t.balance || 0) };
        });
    }

    try {
        const lua = [[
            "local sraw = redis.call('hget', KEYS[1], ARGV[1])",
            "local traw = redis.call('hget', KEYS[1], ARGV[2])",
            "if not sraw or not traw then return {err='missing'} end",
            "local s = cjson.decode(sraw)",
            "local t = cjson.decode(traw)",
            "local amount = tonumber(ARGV[3])",
            "local fee = tonumber(ARGV[4])",
            "if (tonumber(s.balance) or 0) < (amount + fee) then return {err='insufficient'} end",
            "s.balance = (tonumber(s.balance) or 0) - (amount + fee)",
            "t.balance = (tonumber(t.balance) or 0) + amount",
            "redis.call('hset', KEYS[1], ARGV[1], cjson.encode(s), ARGV[2], cjson.encode(t))",
            "return {tostring(s.balance), tostring(t.balance)}"
        ].join('\n')];

        // We store users under hash key 'users'
        const res = await client.eval(lua[0], { keys: ['users'], arguments: [String(senderNumber), String(targetNumber), String(Number(amount || 0)), String(Number(fee || 0))] });
        // res may be an array of two strings
        if (!res || (Array.isArray(res) && res[1] && String(res[1]).startsWith('err='))) {
            return null;
        }
        if (Array.isArray(res) && res.length >= 2) {
            const sbal = Number(res[0] || 0);
            const tbal = Number(res[1] || 0);
            // Update in-memory cache for convenience
            try {
                usersCache = usersCache.map(u => {
                    if (!u || !u.number) return u;
                    if (String(u.number) === String(senderNumber)) { u.balance = sbal; }
                    if (String(u.number) === String(targetNumber)) { u.balance = tbal; }
                    return u;
                });
            } catch (e) { /* ignore cache update errors */ }
            return { senderBalance: sbal, targetBalance: tbal };
        }
        return null;
    } catch (e) {
        console.error('atomicTransfer error:', e);
        return null;
    }
}

// Atomically reserve (subtract) a user's balance if they have sufficient funds.
// Returns new balance as number on success, or null on failure.
async function atomicReserveBalance(number, amount) {
    if (!client) return null;
    try {
        const lua = [
            "local raw = redis.call('hget', KEYS[1], ARGV[1])",
            "if not raw then return {err='missing'} end",
            "local u = cjson.decode(raw)",
            "local amt = tonumber(ARGV[2])",
            "if (tonumber(u.balance) or 0) < amt then return {err='insufficient'} end",
            "u.balance = (tonumber(u.balance) or 0) - amt",
            "redis.call('hset', KEYS[1], ARGV[1], cjson.encode(u))",
            "return tostring(u.balance)"
        ].join('\n');
        const res = await client.eval(lua, { keys: ['users'], arguments: [String(number), String(Number(amount || 0))] });
        if (!res || (typeof res === 'string' && res.startsWith('err='))) return null;
        const bal = Number(res || 0);
        // update cache
        try { usersCache = usersCache.map(u => { if (String(u.number) === String(number)) { u.balance = bal; } return u; }); } catch (e) {}
        return bal;
    } catch (e) { console.error('atomicReserveBalance error:', e); return null; }
}

// Atomically add (release) amount back to user's balance. Returns new balance or null.
async function atomicReleaseBalance(number, amount) {
    if (!client) return null;
    try {
        const lua = [
            "local raw = redis.call('hget', KEYS[1], ARGV[1])",
            "if not raw then return {err='missing'} end",
            "local u = cjson.decode(raw)",
            "local amt = tonumber(ARGV[2])",
            "u.balance = (tonumber(u.balance) or 0) + amt",
            "redis.call('hset', KEYS[1], ARGV[1], cjson.encode(u))",
            "return tostring(u.balance)"
        ].join('\n');
        const res = await client.eval(lua, { keys: ['users'], arguments: [String(number), String(Number(amount || 0))] });
        if (!res || (typeof res === 'string' && res.startsWith('err='))) return null;
        const bal = Number(res || 0);
        try { usersCache = usersCache.map(u => { if (String(u.number) === String(number)) { u.balance = bal; } return u; }); } catch (e) {}
        return bal;
    } catch (e) { console.error('atomicReleaseBalance error:', e); return null; }
}

// Atomically add amount to a user's balance (award). Returns new balance or null.
async function atomicAddToUser(number, amount) {
    if (!client) return null;
    try {
        const lua = [
            "local raw = redis.call('hget', KEYS[1], ARGV[1])",
            "if not raw then return {err='missing'} end",
            "local u = cjson.decode(raw)",
            "local amt = tonumber(ARGV[2])",
            "u.balance = (tonumber(u.balance) or 0) + amt",
            "redis.call('hset', KEYS[1], ARGV[1], cjson.encode(u))",
            "return tostring(u.balance)"
        ].join('\n');
        const res = await client.eval(lua, { keys: ['users'], arguments: [String(number), String(Number(amount || 0))] });
        if (!res || (typeof res === 'string' && res.startsWith('err='))) return null;
        const bal = Number(res || 0);
        try { usersCache = usersCache.map(u => { if (String(u.number) === String(number)) { u.balance = bal; } return u; }); } catch (e) {}
        return bal;
    } catch (e) { console.error('atomicAddToUser error:', e); return null; }
}

// --- Leader election + heartbeat helpers ---
// Minimal helpers for leader lock + pub/sub so processes can coordinate
// key: leader key in Redis, token: instance id, ttl: milliseconds
async function tryAcquireLeader(key, token, ttl = 8000) {
    if (!client) return false;
    try {
        const ok = await client.set(key, String(token), { NX: true, PX: Number(ttl) });
        return Boolean(ok);
    } catch (e) {
        console.error('tryAcquireLeader error:', e);
        return false;
    }
}

async function refreshLeader(key, token, ttl = 8000) {
    if (!client) return false;
    try {
        // Only refresh TTL if the key is still owned by this token
        const lua = `if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('pexpire', KEYS[1], ARGV[2]) else return 0 end`;
        const res = await client.eval(lua, { keys: [key], arguments: [String(token), String(Number(ttl))] });
        return !!res;
    } catch (e) {
        console.error('refreshLeader error:', e);
        return false;
    }
}

async function getLeaderInfo(key) {
    if (!client) return { owner: null, ttl: -2 };
    try {
        const owner = await client.get(key);
        const pttl = await client.pTTL(key);
        return { owner: owner || null, ttl: Number(pttl) };
    } catch (e) {
        console.error('getLeaderInfo error:', e);
        return { owner: null, ttl: -2 };
    }
}

async function releaseLeader(key, token) {
    if (!client) return false;
    try {
        // Reuse the safe release Lua used elsewhere
        const lua = `if redis.call("get", KEYS[1]) == ARGV[1] then return redis.call("del", KEYS[1]) else return 0 end`;
        const res = await client.eval(lua, { keys: [key], arguments: [String(token)] });
        return !!res;
    } catch (e) {
        console.error('releaseLeader error:', e);
        return false;
    }
}

// Pub/Sub helpers (uses a duplicated client for subscription)
let _subscriber = null;
async function _ensureSubscriber() {
    if (_subscriber) return _subscriber;
    if (!client) throw new Error('Redis client not initialized');
    _subscriber = client.duplicate();
    _subscriber.on('error', err => console.error('Redis subscriber error', err));
    await _subscriber.connect();
    return _subscriber;
}

async function publishChannel(channel, message) {
    if (!client) return 0;
    try {
        const payload = (typeof message === 'string') ? message : JSON.stringify(message);
        return await client.publish(channel, payload);
    } catch (e) {
        console.error('publishChannel error:', e);
        return 0;
    }
}

async function subscribeChannel(channel, handler) {
    try {
        const sub = await _ensureSubscriber();
        // node-redis v4 subscribe takes (channel, listener) and returns a promise
        await sub.subscribe(channel, async (msg) => {
            try {
                let parsed = msg;
                try { parsed = JSON.parse(msg); } catch (e) { /* keep raw */ }
                await handler(parsed, msg);
            } catch (e) {
                console.error('subscribeChannel handler error:', e);
            }
        });
        return true;
    } catch (e) {
        console.error('subscribeChannel error:', e);
        return false;
    }
}

// Minimal inflight state helpers to persist small processing state so takeover can inspect
async function setInflight(key, obj, ttl = 60000) {
    if (!client) return false;
    try {
        const payload = JSON.stringify(obj || {});
        await client.set(key, payload, { PX: Number(ttl) });
        try {
            // publish a lightweight event so standbys can react immediately
            await publishChannel('inflight:events', { type: 'set', key, obj });
        } catch (e) { /* ignore publish errors */ }
        return true;
    } catch (e) {
        console.error('setInflight error:', e);
        return false;
    }
}

async function getInflight(key) {
    if (!client) return null;
    try {
        const raw = await client.get(key);
        if (!raw) return null;
        try { return JSON.parse(raw); } catch (e) { return raw; }
    } catch (e) {
        console.error('getInflight error:', e);
        return null;
    }
}

async function clearInflight(key) {
    if (!client) return false;
    try { await client.del(key); return true; } catch (e) { console.error('clearInflight error:', e); return false; }
}

async function clearInflightAndPublish(key) {
    if (!client) return false;
    try {
        await client.del(key);
        try { await publishChannel('inflight:events', { type: 'clear', key }); } catch (e) { /* ignore */ }
        return true;
    } catch (e) { console.error('clearInflight error:', e); return false; }
}

// List inflight keys matching a pattern. For small keyspaces KEYS is acceptable;
// for larger deployments switch to SCAN to avoid blocking Redis.
async function listInflightKeys(pattern = 'inflight:*') {
    if (!client) return [];
    try {
        // Prefer non-blocking iterator if available (node-redis v4)
        if (typeof client.scanIterator === 'function') {
            const keys = [];
            for await (const k of client.scanIterator({ MATCH: pattern, COUNT: 100 })) {
                keys.push(k);
            }
            return keys;
        }
        // Fallback to manual SCAN if available
        if (typeof client.scan === 'function') {
            let cursor = '0';
            const keys = [];
            do {
                const res = await client.scan(cursor, { MATCH: pattern, COUNT: 100 });
                // node-redis may return [cursor, keys]
                if (Array.isArray(res)) {
                    cursor = res[0];
                    const ks = res[1] || [];
                    keys.push(...ks);
                } else if (res && res.cursor !== undefined && Array.isArray(res.keys)) {
                    cursor = String(res.cursor || '0');
                    keys.push(...(res.keys || []));
                } else {
                    break;
                }
            } while (cursor !== '0');
            return keys;
        }
        // Last-resort: KEYS (blocking) for small deployments
        const keys = await client.keys(pattern);
        return Array.isArray(keys) ? keys : [];
    } catch (e) {
        console.error('listInflightKeys error:', e);
        return [];
    }
}

// Return an object mapping inflight key -> parsed value
async function getInflights(pattern = 'inflight:*') {
    try {
        const keys = await listInflightKeys(pattern);
        if (!keys.length) return {};
        const vals = await Promise.all(keys.map(k => client.get(k).catch(() => null)));
        const out = {};
        for (let i = 0; i < keys.length; i++) {
            try { out[keys[i]] = vals[i] ? JSON.parse(vals[i]) : null; } catch (e) { out[keys[i]] = null; }
        }
        return out;
    } catch (e) { console.error('getInflights error', e); return {}; }
}

async function closeSubscriber() {
    try {
        if (_subscriber) {
            try { await _subscriber.disconnect(); } catch (e) { /* ignore */ }
            _subscriber = null;
        }
    } catch (e) { console.error('closeSubscriber error:', e); }
}

// --- Admin status helpers ---
async function setAdminStatus(adminId, status) {
    try {
        if (!adminId) return false;
        if (client) {
            await client.hSet('admin:status', String(adminId), String(status || ''));
            return true;
        }
        // fallback: nothing to do when no client
        return false;
    } catch (e) {
        console.error('setAdminStatus error:', e);
        return false;
    }
}

async function getAdminStatus(adminId) {
    try {
        if (!adminId) return null;
        if (client) {
            const v = await client.hGet('admin:status', String(adminId));
            return (typeof v === 'string' && v.length) ? v : null;
        }
        return null;
    } catch (e) {
        console.error('getAdminStatus error:', e);
        return null;
    }
}

async function getAllAdminStatuses() {
    try {
        if (client) {
            const all = await client.hGetAll('admin:status');
            return all || {};
        }
        return {};
    } catch (e) {
        console.error('getAllAdminStatuses error:', e);
        return {};
    }
}


module.exports = {
    init,
    getAllUsers,
    replaceAllUsers,
    getBank,
    setBank,
    addToBank,
    addHistoryTf,
    getHistoryTf,
    clearHistoryTf,
    getWarns,
    getWarnsAsync,
    setWarn,
    withRegistrationsLock,
    // PVP helpers
    savePvpRoom: savePvpRoomRedis,
    loadPvpRoom: loadPvpRoomRedis,
    deletePvpRoom: deletePvpRoomRedis,
    listPvpRooms: listPvpRoomsRedis,
    findPvpRoomByParticipant: findPvpRoomByParticipantRedis,
    findPvpRoomByCreator: findPvpRoomByCreatorRedis
};

// expose atomicTransfer
module.exports.atomicTransfer = atomicTransfer;

// Export lock helpers for external use
module.exports.acquireLock = _acquireLock;
module.exports.releaseLock = _releaseLock;

// Export new atomic balance helpers
module.exports.atomicReserveBalance = atomicReserveBalance;
module.exports.atomicReleaseBalance = atomicReleaseBalance;
module.exports.atomicAddToUser = atomicAddToUser;

// Leader election + pubsub helpers
module.exports.tryAcquireLeader = tryAcquireLeader;
module.exports.refreshLeader = refreshLeader;
module.exports.getLeaderInfo = getLeaderInfo;
module.exports.releaseLeader = releaseLeader;
module.exports.publishChannel = publishChannel;
module.exports.subscribeChannel = subscribeChannel;
module.exports.setInflight = setInflight;
module.exports.getInflight = getInflight;
module.exports.listInflightKeys = listInflightKeys;
module.exports.getInflights = getInflights;
module.exports.clearInflight = clearInflight;
module.exports.clearInflightAndPublish = clearInflightAndPublish;
module.exports.closeSubscriber = closeSubscriber;

// Admin status exports
module.exports.setAdminStatus = setAdminStatus;
module.exports.getAdminStatus = getAdminStatus;
module.exports.getAllAdminStatuses = getAllAdminStatuses;



