const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createClient: createRedisClient } = require('redis');
const { spawn } = require('child_process');

const DB = require('./db');

// --- Leader election / heartbeat (fast failover) ---
const INSTANCE_ID = process.env.INSTANCE_ID || (crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex'));
const LEADER_KEY = process.env.LEADER_KEY || 'leader:wa';
const HEARTBEAT_CHANNEL = process.env.HEARTBEAT_CHANNEL || (LEADER_KEY + ':hb');
// Faster defaults for quicker failover: adjust via env vars if needed
const LEADER_TTL_MS = Number(process.env.LEADER_TTL_MS || 800); // ~0.8s
const HEARTBEAT_INTERVAL_MS = Number(process.env.HEARTBEAT_INTERVAL_MS || 200); // 200ms
const STANDBY_POLL_MS = Number(process.env.STANDBY_POLL_MS || 200); // 200ms
const STANDBY_TOLERANCE_MS = Number(process.env.STANDBY_TOLERANCE_MS || 300);

let amLeader = false;
let _hbInterval = null;
let _standbyPoll = null;
let _lastHeartbeatAt = 0;

async function _startHeartbeatLoop() {
    if (_hbInterval) clearInterval(_hbInterval);
    // send immediate heartbeat and refresh lock
    try { await DB.refreshLeader(LEADER_KEY, INSTANCE_ID, LEADER_TTL_MS); } catch (e) { }
    try { await DB.publishChannel(HEARTBEAT_CHANNEL, { owner: INSTANCE_ID, ts: Date.now() }); } catch (e) { }
    _hbInterval = setInterval(async () => {
        try {
            const ok = await DB.refreshLeader(LEADER_KEY, INSTANCE_ID, LEADER_TTL_MS);
            if (!ok) {
                // lost leadership unexpectedly
                console.warn('[leader] lost lock during refresh');
                await _becomeStandby();
                return;
            }
            await DB.publishChannel(HEARTBEAT_CHANNEL, { owner: INSTANCE_ID, ts: Date.now() });
        } catch (e) {
            console.error('[leader] heartbeat error', e);
        }
    }, Math.max(100, HEARTBEAT_INTERVAL_MS));
}

async function _stopHeartbeatLoop() {
    if (_hbInterval) { clearInterval(_hbInterval); _hbInterval = null; }
}

async function _attemptAcquireLeadership() {
    try {
        const ok = await DB.tryAcquireLeader(LEADER_KEY, INSTANCE_ID, LEADER_TTL_MS);
        if (ok) {
            console.log('[leader] acquired leadership', INSTANCE_ID);
            await _becomeLeader();
            return true;
        }
        return false;
    } catch (e) {
        console.error('[leader] tryAcquire error', e);
        return false;
    }
}

async function _becomeLeader() {
    // stop standby poll
    if (_standbyPoll) { clearInterval(_standbyPoll); _standbyPoll = null; }
    amLeader = true;
    await _startHeartbeatLoop();
    // Claim any inflight tasks left by previous leader and notify users
    try {
        await _replayInflightsOnTakeover();
    } catch (e) {
        console.error('Error replaying inflights on takeover:', e);
    }
}

async function _replayInflightsOnTakeover() {
    try {
        if (!DB || typeof DB.getInflights !== 'function') return;
        const inflights = await DB.getInflights('inflight:*');
        const keys = Object.keys(inflights || {});
        if (!keys.length) return;
        console.log('[leader] claiming inflight keys:', keys.length);
        for (const k of keys) {
            const p = inflights[k];
            if (!p || !p.chatId) continue;
            try {
                // Notify chat that takeover is attempting to resume/inspect pending command
                const notice = `⚠️ Sistem takeover: memproses pesan tertunda dari ${p.sender || 'pengguna'}. Jika perintah belum selesai, silakan coba ulang.`;
                await sendQueue(p.chatId, notice, undefined, 'high');
            } catch (e) {
                console.error('replay send failed', e);
            }
            try { await DB.clearInflight(k); } catch (e) { /* ignore */ }
        }
    } catch (e) { console.error('replayInflightsOnTakeover error', e); }
}

async function _becomeStandby() {
    amLeader = false;
    await _stopHeartbeatLoop();
    _lastHeartbeatAt = Date.now();

    // subscribe to heartbeats to detect liveness quickly
    try {
        await DB.subscribeChannel(HEARTBEAT_CHANNEL, async (msg) => {
            try {
                if (msg && msg.owner) {
                    _lastHeartbeatAt = Date.now();
                }
            } catch (e) { /* ignore */ }
        });
    } catch (e) { /* ignore */ }

    // poll leader key TTL: try to take over when missing
    if (_standbyPoll) clearInterval(_standbyPoll);
    _standbyPoll = setInterval(async () => {
        try {
            const info = await DB.getLeaderInfo(LEADER_KEY);
            const exists = info && info.owner;
            const ttl = (info && typeof info.ttl === 'number') ? info.ttl : -2;
            const sinceLastHB = Date.now() - _lastHeartbeatAt;
            // If no owner or no TTL or heartbeat stale, attempt takeover
            if (!exists || ttl <= 0 || sinceLastHB > Math.max(LEADER_TTL_MS, HEARTBEAT_INTERVAL_MS) + STANDBY_TOLERANCE_MS) {
                const got = await _attemptAcquireLeadership();
                if (got) return;
            }
        } catch (e) { /* ignore */ }
    }, Math.max(100, STANDBY_POLL_MS));
}
// bootstrap: initialize DB then attempt election
(async () => {
    try {
        try { await DB.init(); } catch (e) { console.error('[leader] DB.init error', e); }
        const got = await _attemptAcquireLeadership();
        if (!got) await _becomeStandby();
    } catch (e) {
        console.error('[leader] bootstrap error', e);
    }
})();

// ensure graceful release on shutdown
process.on('SIGINT', async () => {
    try { if (amLeader) await DB.releaseLeader(LEADER_KEY, INSTANCE_ID); } catch (e) { }
    try { await DB.publishChannel(HEARTBEAT_CHANNEL, { owner: null, ts: Date.now(), reason: 'shutdown' }); } catch (e) { }
    try { await DB.closeSubscriber(); } catch (e) { }
    process.exit(0);
});
process.on('SIGTERM', async () => {
    try { if (amLeader) await DB.releaseLeader(LEADER_KEY, INSTANCE_ID); } catch (e) { }
    try { await DB.publishChannel(HEARTBEAT_CHANNEL, { owner: null, ts: Date.now(), reason: 'shutdown' }); } catch (e) { }
    try { await DB.closeSubscriber(); } catch (e) { }
    process.exit(0);
});

// Enable verbose admin-detection debug by setting env var `ADMIN_DEBUG=1`
const ADMIN_DEBUG = String(process.env.ADMIN_DEBUG || '').trim() === '1';

// legacy JSON paths removed: storage now handled by `DB` module
// Only allow responding in these group JIDs; editable at runtime via .groupfilter
let ALLOWED_GROUPS = ['120363402331100666@g.us', '120363423236567094@g.us', '120363422082156619@g.us', '120363421350362029@g.us', '120363406545005420@g.us', '120363405493948959@g.us', '120363406162170143@g.us', '120363402204334340@g.us'];
//let ALLOWED_GROUPS = ['120363405222168854@g.us'];
// When true the bot will only respond in groups listed in ALLOWED_GROUPS
let GROUP_FILTER_ENABLED = true;

// === Message Queue Implementation ===
class MessageQueue {
    constructor(concurrency = 8, minDelay = 500) {
        this.highPriority = [];
        this.lowPriority = [];
        this.concurrency = concurrency;
        this.minDelay = minDelay;
        this.active = 0;
        this.lastProcessTime = 0;
    }

    /**
     * Add a task to the queue.
     * @param {string} priority - 'high' or 'low'
     * @param {Function} fn - Async function to execute
     */
    add(priority, fn) {
        return new Promise((resolve, reject) => {
            const task = { fn, resolve, reject };
            if (priority === 'high') {
                this.highPriority.push(task);
            } else {
                this.lowPriority.push(task);
            }
            this.process();
        });
    }

    async process() {
        if (this.active >= this.concurrency) return;

        // Simple rate limiting: ensure we don't start tasks too rapidly in succession
        const now = Date.now();
        const timeSinceLast = now - this.lastProcessTime;
        if (timeSinceLast < this.minDelay) {
            setTimeout(() => this.process(), this.minDelay - timeSinceLast);
            return;
        }



        const task = this.highPriority.shift() || this.lowPriority.shift();
        if (!task) return;

        this.active++;
        this.lastProcessTime = Date.now();

        // Run the task
        task.fn().then(task.resolve).catch(task.reject).finally(() => {
            this.active--;
            this.process();
        });
    }
}

// Global message queue instance
const messageQueue = new MessageQueue(8, 100); // 8 concurrent, 100ms delay between starts

// Helper to wrap send operations
async function queueSend(priority, fn) {
    // Dispatch to fast or bulk queue depending on priority.
    // High-priority messages (interactive, short replies) should go through the fastQueue;
    // low-priority/bulk messages (broadcasts, tagall) go through the bulkQueue.
    const fastQueue = (global.__fastMessageQueue__ = global.__fastMessageQueue__ || new MessageQueue(Number(process.env.FAST_QUEUE_CONCURRENCY || 2), Number(process.env.FAST_QUEUE_MIN_DELAY_MS || 20)));
    const bulkQueue = (global.__bulkMessageQueue__ = global.__bulkMessageQueue__ || new MessageQueue(Number(process.env.BULK_QUEUE_CONCURRENCY || 6), Number(process.env.BULK_QUEUE_MIN_DELAY_MS || 150)));

    const q = (String(priority || 'high') === 'high') ? fastQueue : bulkQueue;
    // Map to simple 'high'/'low' priority within each queue
    const qprio = (String(priority || 'high') === 'high') ? 'high' : 'low';
    return q.add(qprio, fn);
}

async function sendQueue(chatId, content, options, priority = 'high') {
    return queueSend(priority, () => client.sendMessage(chatId, content, options));
}

async function replyQueue(msg, content, options, priority = 'high') {
    // msg.reply(content, chatId, options) - we pass undefined for chatId to reply to the msg's chat
    return queueSend(priority, () => msg.reply(content, undefined, options));
}

// immediateReply: try to reply directly for very short/interactive responses.
// Falls back to enqueueing if direct reply fails (rate-limit or other error).
async function immediateReply(msg, content, options) {
    try {
        if (msg && typeof msg.reply === 'function') {
            await msg.reply(content, undefined, options);
            return true;
        }
    } catch (err) {
        console.warn('immediateReply failed, enqueueing:', err && err.message);
    }
    // fallback to queue (high priority)
    await replyQueue(msg, content, options, 'high');
    return false;
}
// ====================================

// In-memory maps for active room timeouts and cached rooms
const pvpRoomTimeouts = new Map();
const pvpActiveTimeouts = new Map();

// legacy pvp directory helpers removed: PvP rooms persisted in DB/Redis now

function clearActiveTimer(code) {
    try {
        if (pvpActiveTimeouts.has(code)) {
            clearTimeout(pvpActiveTimeouts.get(code));
            pvpActiveTimeouts.delete(code);
        }
    } catch (e) { /* ignore */ }
}

function startActiveTimer(code, chatId) {
    try {
        clearActiveTimer(code);
        const t = setTimeout(async () => {
            try {
                const room = await loadPvpRoom(code);
                if (!room) return;
                if (room.status !== 'active') return;
                const round = room.currentRound || 1;
                const results = (room.results && room.results[round]) || {};
                const players = Array.isArray(room.participants) ? room.participants.map(p => p.number) : [];

                const keys = Object.keys(results || {});
                // No one spun: refund both and delete room
                if (keys.length === 0) {
                    (async () => {
                        try {
                            const tb = Number(room.totalbet || 0);
                            if (tb > 0 && DB && typeof DB.atomicReleaseBalance === 'function') {
                                for (const p of players) {
                                    try { await DB.atomicReleaseBalance(p, tb); } catch (e) { /* ignore per-player */ }
                                }
                                invalidateRegsCache();
                            } else {
                                await withRegistrationsLock(async (regsNow) => {
                                    for (const p of players) {
                                        const r = regsNow.find(x => x.number === p);
                                        if (r) r.balance = Number(r.balance || 0) + tb;
                                    }
                                });
                            }
                            const mentions = players.map(n => ensureSerializedId((loadRegistrations().find(r => r.number === n) || {}).uid || n)).filter(Boolean);
                            const msgText = `Room pvp ${code} dihapus karena kedua pemain tidak melakukan .gass dalam 3 menit. Coin otomatis dikembalikan.`;
                            if (mentions.length) sendQueue(chatId || room.groupId, msgText, { mentions }); else sendQueue(chatId || room.groupId, msgText);
                        } catch (e) {
                            console.error('Gagal refund on inactive pvp:', e);
                        }
                        await deletePvpRoomFile(code);
                        clearActiveTimer(code);
                        if (pvpRoomTimeouts.has(code)) { clearTimeout(pvpRoomTimeouts.get(code)); pvpRoomTimeouts.delete(code); }
                        return;
                    })();
                }

                // One player spun: award spinner as winner automatically
                if (keys.length === 1) {
                    const winnerNumber = keys[0];
                    (async () => {
                        try {
                            let found = null;
                            try {
                                const escrow = Number(room.escrow || 0);
                                const fee = Math.floor(escrow * 0.035);
                                const award = escrow - fee;
                                if (DB && typeof DB.atomicAddToUser === 'function') {
                                    const newBal = await DB.atomicAddToUser(winnerNumber, award);
                                    if (newBal === null) {
                                        // couldn't award
                                    } else {
                                        found = { wreg: { number: winnerNumber }, award, fee };
                                    }
                                } else {
                                    await withRegistrationsLock(async (regsNow) => {
                                        const wreg = regsNow.find(r => r.number === winnerNumber);
                                        if (!wreg) return;
                                        wreg.balance = Number(wreg.balance || 0) + (escrow - Math.floor(escrow * 0.035));
                                        found = { wreg, award: escrow - Math.floor(escrow * 0.035), fee: Math.floor(escrow * 0.035) };
                                    });
                                }
                                if (found && found.fee) addToBank(found.fee);
                                if (found && found.wreg) {
                                    const reg = loadRegistrations().find(r => r.number === winnerNumber);
                                    if (reg) found.wreg = reg;
                                }
                            } catch (e) {
                                console.error('Gagal menetapkan pemenang timeout:', e);
                            }
                            if (!found) {
                                sendQueue(chatId || room.groupId, `Pemenang otomatis terdeteksi (${winnerNumber}), tetapi gagal mengupdate saldo (registrasi tidak ditemukan).`);
                                await deletePvpRoomFile(code);
                                clearActiveTimer(code);
                                return;
                            }

                            const wreg = found.wreg;
                            const award = found.award;
                            const wm = ensureSerializedId(wreg.uid || wreg.number);
                            const winnerDisplay = wm ? `@${wm.split('@')[0]}` : wreg.number;
                            const feePct = '3.5%';
                            const msgLines = [];
                            msgLines.push(`⏱️ *PVP REME TIMEOUT - ROOM ${room.code}* ⏱️\n`);
                            msgLines.push(`Salah satu pemain tidak menyelesaikan giliran mereka dalam waktu 3 menit!\n`);
                            msgLines.push(`🏆 Pemenang: ${winnerDisplay}`);
                            msgLines.push(`💰 Hadiah: ${formatNumber(award)} (sudah dipotong fee ${feePct})\n`);
                            msgLines.push('Trima kasih telah bermain!');
                            const finalMsg = msgLines.join('\n');
                            if (wm) sendQueue(chatId || room.groupId, finalMsg, { mentions: [wm] }); else sendQueue(chatId || room.groupId, finalMsg);
                        } catch (e) {
                            console.error('Gagal menetapkan pemenang timeout:', e);
                        }
                        await deletePvpRoomFile(code);
                        clearActiveTimer(code);
                        if (pvpRoomTimeouts.has(code)) { clearTimeout(pvpRoomTimeouts.get(code)); pvpRoomTimeouts.delete(code); }
                        return;
                    })();
                }

                // If both spun (should have been resolved already), do nothing
            } catch (e) {
                console.error('Error in active timer handler:', e);
            }
        }, 3 * 60 * 1000);
        pvpActiveTimeouts.set(code, t);
    } catch (e) {
        console.error('Gagal memulai active timer:', e);
    }
}
// pvpRoomPath removed; DB module handles PvP room storage (Redis)

async function savePvpRoom(room) {
    try {
        if (!DB || typeof DB.savePvpRoom !== 'function') return;
        await DB.savePvpRoom(room);
    } catch (e) {
        console.error('Gagal menyimpan room pvp:', e);
    }
}

async function loadPvpRoom(code) {
    try {
        if (!DB || typeof DB.loadPvpRoom !== 'function') return null;
        return await DB.loadPvpRoom(code);
    } catch (e) {
        console.error('Gagal membaca room pvp:', e);
        return null;
    }
}

async function deletePvpRoomFile(code) {
    try {
        if (!DB || typeof DB.deletePvpRoom !== 'function') return;
        await DB.deletePvpRoom(code);
    } catch (e) {
        console.error('Gagal menghapus file room pvp:', e);
    }
}

async function listPvpRooms() {
    try {
        if (!DB || typeof DB.listPvpRooms !== 'function') return [];
        return await DB.listPvpRooms();
    } catch (e) {
        return [];
    }
}

async function findPvpRoomByParticipant(number) {
    try {
        if (!DB || typeof DB.findPvpRoomByParticipant !== 'function') return null;
        return await DB.findPvpRoomByParticipant(number);
    } catch (e) { return null; }
}

async function findPvpRoomByCreator(number) {
    try {
        if (!DB || typeof DB.findPvpRoomByCreator !== 'function') return null;
        return await DB.findPvpRoomByCreator(number);
    } catch (e) { return null; }
}

// Helper: admin add balance using atomic DB helper when available
async function adminAddBalance(targetObj, amount, msg) {
    try {
        const regsSnapshot = loadRegistrations();
        const reg = findRegistrationForTarget(targetObj, regsSnapshot);
        const display = (reg && reg.number) || (targetObj.number || targetObj.uid);
        if (!reg) {
            replyQueue(msg, `Pengguna ${display} belum teregistrasi.`, undefined, 'high');
            return;
        }
        if (DB && typeof DB.atomicAddToUser === 'function') {
            const newBal = await DB.atomicAddToUser(reg.number, amount);
            if (newBal === null) { replyQueue(msg, `Gagal memperbarui saldo untuk ${display}.`, undefined, 'high'); return; }
            invalidateRegsCache();
            const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
            const addedFmt = formatNumber(amount);
            const currentFmt = formatNumber(newBal);
            if (maybeId) replyQueue(msg, `✅ Berhasil menambahkan ${addedFmt} Coin ke @${maybeId.split('@')[0]}.\n💰 Coin saat ini: *${currentFmt} Coin*`, { mentions: [maybeId] }, 'high');
            else replyQueue(msg, `✅ Berhasil menambahkan ${addedFmt} Coin ke ${display}.\n💰 Coin saat ini: *${currentFmt} Coin*`, undefined, 'high');
            return;
        }

        // Fallback
        await withRegistrationsLock(async (regsNow) => {
            const r = findRegistrationForTarget(targetObj, regsNow);
            const display2 = (r && r.number) || (targetObj.number || targetObj.uid);
            if (!r) { replyQueue(msg, `Pengguna ${display2} belum teregistrasi.`, undefined, 'high'); return; }
            r.balance = Number(r.balance || 0) + amount;
            const maybeId = ensureSerializedId((r && r.uid) || r.number || targetObj.uid || targetObj.number);
            const addedFmt = formatNumber(amount);
            const currentFmt = formatNumber(r.balance);
            if (maybeId) replyQueue(msg, `✅ Berhasil menambahkan ${addedFmt} Coin ke @${maybeId.split('@')[0]}.\n💰 Coin saat ini: *${currentFmt} Coin*`, { mentions: [maybeId] }, 'high');
            else replyQueue(msg, `✅ Berhasil menambahkan ${addedFmt} Coin ke ${display2}.\n💰 Coin saat ini: *${currentFmt} Coin*`, undefined, 'high');
        });
    } catch (e) {
        console.error('adminAddBalance error:', e);
        replyQueue(msg, 'Terjadi kesalahan saat menambahkan saldo.', undefined, 'high');
    }
}

// Helper: admin remove balance using atomic DB helper when available
async function adminRemoveBalance(targetObj, amount, msg) {
    try {
        const regsSnapshot = loadRegistrations();
        const reg = findRegistrationForTarget(targetObj, regsSnapshot);
        const display = (reg && reg.number) || (targetObj.number || targetObj.uid);
        if (!reg) { replyQueue(msg, `Pengguna ${display} belum teregistrasi.`, undefined, 'high'); return; }
        if (DB && typeof DB.atomicReserveBalance === 'function') {
            try { await DB.setInflight(inflightKey, { instance: INSTANCE_ID, chatId: (chat && chat.id && chat.id._serialized) || null, sender: senderNumber, body, ts: Date.now(), stage: 'reserving' }, 30 * 1000); } catch (e) { /* ignore */ }
            const newBal = await DB.atomicReserveBalance(reg.number, amount);
            try { await DB.setInflight(inflightKey, { instance: INSTANCE_ID, chatId: (chat && chat.id && chat.id._serialized) || null, sender: senderNumber, body, ts: Date.now(), stage: 'reserved' }, 30 * 1000); } catch (e) { /* ignore */ }
            if (newBal === null) {
                const current = Number(reg.balance || 0);
                const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
                if (maybeId) replyQueue(msg, `Saldo @${maybeId.split('@')[0]} tidak cukup (saat ini ${current}).`, { mentions: [maybeId] }, 'high');
                else replyQueue(msg, `Saldo ${display} tidak cukup (saat ini ${current}).`, undefined, 'high');
                return;
            }
            invalidateRegsCache();
            const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
            const removedFmt = formatNumber(amount);
            const currentFmt = formatNumber(newBal);
            if (maybeId) replyQueue(msg, `✅ Berhasil mengurangi ${removedFmt} Coin dari @${maybeId.split('@')[0]}.\n💰 Coin saat ini: *${currentFmt} Coin*`, { mentions: [maybeId] }, 'high');
            else replyQueue(msg, `✅ Berhasil mengurangi ${removedFmt} Coin dari ${display}.\n💰 Coin saat ini: *${currentFmt} Coin*`, undefined, 'high');
            return;
        }

        // Fallback
        await withRegistrationsLock(async (regsNow) => {
            const r = findRegistrationForTarget(targetObj, regsNow);
            const display2 = (r && r.number) || (targetObj.number || targetObj.uid);
            if (!r) { replyQueue(msg, `Pengguna ${display2} belum teregistrasi.`, undefined, 'high'); return; }
            const current = Number(r.balance || 0);
            if (current < amount) {
                const maybeId = ensureSerializedId((r && r.uid) || r.number || targetObj.uid || targetObj.number);
                if (maybeId) replyQueue(msg, `Saldo @${maybeId.split('@')[0]} tidak cukup (saat ini ${current}).`, { mentions: [maybeId] }, 'high');
                else replyQueue(msg, `Saldo ${display2} tidak cukup (saat ini ${current}).`, undefined, 'high');
                return;
            }
            r.balance = current - amount;
            const maybeId = ensureSerializedId((r && r.uid) || r.number || targetObj.uid || targetObj.number);
            const removedFmt = formatNumber(amount);
            const currentFmt = formatNumber(r.balance);
            if (maybeId) replyQueue(msg, `✅ Berhasil mengurangi ${removedFmt} Coin dari @${maybeId.split('@')[0]}.\n💰 Coin saat ini: *${currentFmt} Coin*`, { mentions: [maybeId] }, 'high');
            else replyQueue(msg, `✅ Berhasil mengurangi ${removedFmt} Coin dari ${display2}.\n💰 Coin saat ini: *${currentFmt} Coin*`, undefined, 'high');
        });
    } catch (e) {
        console.error('adminRemoveBalance error:', e);
        replyQueue(msg, 'Terjadi kesalahan saat mengurangi saldo.', undefined, 'high');
    }
}

// Lightweight in-process cache for registrations to avoid repeated DB.getAllUsers() calls
const _regsCache = { value: null, expiresAt: 0, ttl: Number(process.env.REGS_CACHE_TTL_MS || 30000) };
function loadRegistrations() {
    try {
        if (_regsCache.value && Date.now() < _regsCache.expiresAt) return _regsCache.value.slice();
        const all = DB.getAllUsers() || [];
        _regsCache.value = Array.isArray(all) ? all.slice() : [];
        _regsCache.expiresAt = Date.now() + _regsCache.ttl;
        return _regsCache.value.slice();
    } catch (e) { console.error('loadRegistrations error:', e); return []; }
}

function saveRegistrations(arr) {
    try {
        // Invalidate cache immediately to ensure subsequent reads are fresh
        _regsCache.value = null;
        DB.replaceAllUsers(arr || []);
    } catch (e) { console.error('saveRegistrations error:', e); }
}

function invalidateRegsCache() { _regsCache.value = null; }

// Simple async file lock to protect read-modify-write sequences across
// concurrent handlers and across processes. Uses a lockfile next to the
// target DB file and retries for a short period.
// File-system based locking removed in favor of Redis-based locks (see DB.withRegistrationsLock)
// Deprecated no-op placeholders kept for compatibility if accidentally referenced.
function acquireFileLock() { return Promise.resolve(); }
function releaseFileLock() { return; }

// In-process mutex queue to serialize lock acquisition attempts and
// ensure handlers in the same Node process don't race.
let _regQueue = Promise.resolve();

function withRegistrationsLock(fn) {
    return DB.withRegistrationsLock(fn);
}

// history persistence and legacy backup helpers removed; DB module used instead

function formatUTC7(d) {
    try {
        const date = (d instanceof Date) ? new Date(d.getTime()) : new Date(d);
        // convert to UTC+7 by adding 7 hours
        const utc7 = new Date(date.getTime() + 7 * 60 * 60 * 1000);
        const Y = utc7.getUTCFullYear();
        const M = String(utc7.getUTCMonth() + 1).padStart(2, '0');
        const D = String(utc7.getUTCDate()).padStart(2, '0');
        const h = String(utc7.getUTCHours()).padStart(2, '0');
        const m = String(utc7.getUTCMinutes()).padStart(2, '0');
        const s = String(utc7.getUTCSeconds()).padStart(2, '0');
        return `${Y}-${M}-${D} ${h}:${m}:${s}`;
    } catch (e) {
        return new Date().toISOString();
    }
}

function ensureBank() {
    try { return DB.getBank() || { total: 0, updatedAt: new Date().toISOString() }; } catch (e) { console.error('ensureBank error:', e); return { total: 0, updatedAt: new Date().toISOString() }; }
}

function loadBank() {
    try { return DB.getBank() || ensureBank(); } catch (e) { console.error('loadBank error:', e); return ensureBank(); }
}

function loadWarns() {
    try { return DB.getWarns(); } catch (e) { console.error('loadWarns error:', e); return {}; }
}

function saveWarns(obj) {
    try {
        if (!obj || typeof obj !== 'object') return;
        for (const k of Object.keys(obj)) {
            DB.setWarn(k, Number(obj[k] || 0));
        }
    } catch (e) { console.error('saveWarns error:', e); }
}

function addWarning(number) {
    try {
        const key = String(number || '');
        const warns = DB.getWarns();
        const prev = Number(warns[key] || 0) + 1;
        DB.setWarn(key, prev);
        return prev;
    } catch (e) {
        console.error('Gagal menambah warning:', e);
        return null;
    }
}

function saveBank(obj) {
    try { DB.setBank(Number((obj && obj.total) || 0)); } catch (e) { console.error('saveBank error:', e); }
}

function addToBank(amount) {
    try {
        const next = DB.addToBank(Number(amount || 0));
        return { total: next, updatedAt: new Date().toISOString() };
    } catch (e) {
        console.error('Gagal menambah ke bank:', e);
        return null;
    }
}

function sumDigits(n) {
    try {
        const s = String(Math.abs(Number(n || 0)));
        const sum = s.split('').reduce((acc, ch) => acc + (parseInt(ch, 10) || 0), 0);
        // Return modulo 10 so sums like 10 -> 0, 11 -> 1, 29 -> 11 -> 1
        return sum % 10;
    } catch (e) {
        return 0;
    }
}

function formatNumber(n) {
    try {
        const num = Number(n || 0);
        return String(num).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    } catch (e) { return String(n || 0); }
}

// Parse an amount token that may include a trailing 'k' (thousands).
// Examples:
//  "5k" -> 5000
//  "1.5k" -> 1500
//  "1000" -> 1000
// Falls back to stripping non-digits if pattern not recognized.
function parseAmountToken(token) {
    try {
        if (token === undefined || token === null) return 0;
        let s = String(token).trim().toLowerCase();
        if (!s) return 0;
        // normalize common separators and whitespace
        s = s.replace(/\s+/g, '');
        // allow comma as decimal separator, convert to dot
        s = s.replace(/,/g, '.');

        const m = s.match(/^([0-9]+(?:\.[0-9]+)?)(k)?$/i);
        if (!m) {
            // fallback: strip non-digits and parse integer
            const digits = s.replace(/[^0-9]/g, '');
            return digits ? parseInt(digits, 10) : 0;
        }
        let num = parseFloat(m[1]);
        if (m[2] && m[2].toLowerCase() === 'k') num = Math.round(num * 1000);
        else num = Math.round(num);
        return Number.isFinite(num) ? num : 0;
    } catch (e) { return 0; }
}

// Ensure a uid or number is returned as a serialized WhatsApp id (e.g. 628123...@c.us)
function ensureSerializedId(val) {
    if (!val) return null;
    if (typeof val !== 'string') val = String(val);
    if (val.includes('@')) return val;
    // strip non-digits then append domain
    const digits = val.replace(/[^0-9]/g, '');
    if (!digits) return null;
    return digits + '@c.us';
}

// Parse mentioned target: return object { number, uid }
async function getMentionedTarget(msg, text) {
    try {
        if (msg && msg.mentionedIds && Array.isArray(msg.mentionedIds) && msg.mentionedIds.length > 0) {
            let rawUid = msg.mentionedIds[0];
            // ensure uid has domain; if missing, try @c.us
            let uidToResolve = rawUid.includes('@') ? rawUid : (rawUid + '@c.us');
            try {
                const contact = await getContactCached(uidToResolve);
                if (contact && contact.id && contact.id._serialized) {
                    const uid = contact.id._serialized;
                    const number = uid.split('@')[0];
                    return { uid, number };
                }
            } catch (e) {
                // fallback to raw uid parsing
                const number = rawUid.split('@')[0];
                return { uid: rawUid, number };
            }
        }
    } catch (e) {
        // ignore
    }

    // Fallback: try to parse digits after an @ in the message text
    if (typeof text === 'string') {
        const m = text.match(/@\+?([0-9]{6,})/);
        if (m && m[1]) return { number: m[1].replace(/^\+/, '') };
    }
    return null;
}

// Try to find a registration matching a mention obj. Matches by uid, exact number,
// then by suffix (fallback) to handle cases where mention resolves to internal id.
function findRegistrationForTarget(targetObj, regs) {
    if (!targetObj || !Array.isArray(regs)) return null;

    if (targetObj.uid) {
        const byUid = regs.find(r => r.uid === targetObj.uid);
        if (byUid) return byUid;
    }

    if (targetObj.number) {
        const normalized = (targetObj.number || '').replace(/[^0-9]/g, '');
        // exact match first
        const byNumber = regs.find(r => r.number === normalized);
        if (byNumber) return byNumber;

        // fallback: try matching by suffix (longest first)
        for (let len = 10; len >= 6; len--) {
            const suffix = normalized.slice(-len);
            if (!suffix) continue;
            const found = regs.find(r => (r.number || '').endsWith(suffix));
            if (found) return found;
        }
    }

    return null;
}

// Robust admin detection: check participant flags and fallback to chat.getAdmins()
async function isSenderAdmin(chat, senderId) {
    try {
        // Normalize sender id (ensure domain present) and a plain number for looser comparisons
        const normalizedId = (typeof ensureSerializedId === 'function') ? (ensureSerializedId(senderId) || senderId) : senderId;
        const plainNumber = (normalizedId && String(normalizedId).split('@')[0]) || senderId;

        if (ADMIN_DEBUG) {
            try {
                console.debug('isSenderAdmin called', { senderId, normalizedId, plainNumber, participants: (chat && chat.participants && chat.participants.length) || 0 });
            } catch (e) { /* ignore debug error */ }
        }

        if (chat && Array.isArray(chat.participants)) {
            const p = chat.participants.find(x => {
                if (!x || !x.id) return false;
                const sid = x.id._serialized || (x.id && x.id.user && `${x.id.user}@c.us`);
                return sid === senderId || sid === normalizedId || (sid && sid.split('@')[0] === plainNumber);
            });
            if (p) {
                if (ADMIN_DEBUG) console.debug('isSenderAdmin - matched participant', p);
                // Accept boolean flags, string flags, role names and owner/creator flags
                if (p.isAdmin === true || p.isSuperAdmin === true || p.isOwner === true || p.isCreator === true) return true;
                if (p.role === 'admin' || p.role === 'superadmin' || p.role === 'creator' || p.role === 'owner') return true;
                if (p.isAdmin === 'admin' || p.isAdmin === 'superadmin' || p.isAdmin === 'creator' || p.isAdmin === 'owner') return true;
            }
        }

        // Fallback: use chat.getAdmins() which returns Contact objects
        if (chat && typeof chat.getAdmins === 'function') {
            const admins = await chat.getAdmins();
            if (ADMIN_DEBUG) {
                try { console.debug('isSenderAdmin - chat.getAdmins result', (Array.isArray(admins) && admins.map(a => (a && a.id && a.id._serialized) || null))); } catch (e) { /* ignore */ }
            }
            if (Array.isArray(admins) && admins.some(a => {
                if (!a || !a.id) return false;
                const sid = a.id._serialized || (a.id && a.id.user && `${a.id.user}@c.us`);
                return sid === senderId || sid === normalizedId || (sid && sid.split('@')[0] === plainNumber);
            })) return true;
        }

        // Some chat objects expose creator/owner fields (try matching them too)
        if (chat) {
            const maybeCreators = [chat.creatorUid, chat.creator, chat.owner, chat.createdBy].filter(Boolean);
            if (ADMIN_DEBUG && maybeCreators.length) console.debug('isSenderAdmin - maybeCreators', maybeCreators);
            for (const c of maybeCreators) {
                const sc = (typeof ensureSerializedId === 'function') ? (ensureSerializedId(c) || c) : c;
                if (!sc) continue;
                if (sc === senderId || sc === normalizedId || (sc.split && sc.split('@')[0] === plainNumber)) {
                    if (ADMIN_DEBUG) console.debug('isSenderAdmin - matched creator field', c);
                    return true;
                }
            }
        }
    } catch (e) {
        console.error('Error checking admin status:', e);
    }
    if (ADMIN_DEBUG) console.debug('isSenderAdmin - no admin match for', senderId);
    return false;
}

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: {
        headless: true,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-gpu',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--disable-web-security',
            '--disable-features=IsolateOrigins,site-per-process',
            '--disable-features=VizDisplayCompositor',
            '--single-process',
            '--no-zygote',
            '--renderer-process-limit=1',
            '--no-first-run',
            '--no-default-browser-check',
            '--disable-background-networking',
            '--disable-background-timer-throttling',
            '--disable-backgrounding-occluded-windows',
            '--disable-breakpad',
            '--disable-client-side-phishing-detection',
            '--disable-component-update',
            '--disable-default-apps',
            '--disable-domain-reliability',
            '--disable-extensions',
            '--disable-hang-monitor',
            '--disable-ipc-flooding-protection',
            '--disable-notifications',
            '--disable-offer-store-unmasked-wallet-cards',
            '--disable-popup-blocking',
            '--disable-prompt-on-repost',
            '--disable-renderer-backgrounding',
            '--disable-sync',
            '--force-color-profile=srgb',
            '--metrics-recording-only',
            '--mute-audio',
            '--no-crash-upload',
            '--no-pings',
            '--password-store=basic',
            '--use-gl=swiftshader',
            '--use-mock-keychain',
            '--disable-software-rasterizer'
        ]
    },
    ffmpegPath: null, // Disable ffmpeg if not needed
    downloadMedia: false // Disable auto download media
});

// Try to clear browser cache (without clearing cookies) via DevTools Protocol.
// Attempts multiple access points to the underlying Puppeteer Page/Browser
// to maintain compatibility with different whatsapp-web.js versions.
async function clearBrowserCacheOnly() {
    try {
        const pages = [];
        try {
            if (client && client.pupPage) pages.push(client.pupPage);
        } catch (e) { /* ignore */ }
        try {
            if (client && client.page) pages.push(client.page);
        } catch (e) { /* ignore */ }
        try {
            if (client && client._page) pages.push(client._page);
        } catch (e) { /* ignore */ }
        try {
            if (client && client.browser && typeof client.browser.pages === 'function') {
                const pgs = await client.browser.pages();
                if (Array.isArray(pgs)) pages.push(...pgs);
            }
        } catch (e) { /* ignore */ }
        try {
            if (client && client.puppeteer && typeof client.puppeteer.pages === 'function') {
                const pgs = await client.puppeteer.pages();
                if (Array.isArray(pgs)) pages.push(...pgs);
            }
        } catch (e) { /* ignore */ }
        // de-duplicate
        const uniq = Array.from(new Set(pages.filter(Boolean)));
        if (!uniq.length) {
            // best-effort: try browser from client.getBrowser() if available
            try {
                if (typeof client.getBrowser === 'function') {
                    const b = await client.getBrowser();
                    if (b && typeof b.pages === 'function') {
                        const pgs = await b.pages();
                        if (Array.isArray(pgs) && pgs.length) uniq.push(...pgs);
                    }
                }
            } catch (e) { /* ignore */ }
        }

        if (!uniq.length) throw new Error('No Puppeteer pages found to clear cache');

        let succeeded = false;
        for (const p of uniq) {
            try {
                // Preferred: create CDP session via page.target().createCDPSession()
                let ses = null;
                try {
                    if (p && typeof p.target === 'function' && p.target()) {
                        const t = p.target();
                        if (t && typeof t.createCDPSession === 'function') ses = await t.createCDPSession();
                    }
                } catch (e) { /* ignore */ }
                // Fallbacks
                if (!ses && p && p._client && typeof p._client.send === 'function') ses = p._client;
                if (!ses && typeof p.createCDPSession === 'function') {
                    try { ses = await p.createCDPSession(); } catch (e) { /* ignore */ }
                }

                if (!ses || typeof ses.send !== 'function') continue;

                // Clear browser cache only (preserve cookies)
                await ses.send('Network.clearBrowserCache');
                succeeded = true;
            } catch (e) {
                // continue to other pages
            }
        }
        return succeeded;
    } catch (err) {
        console.error('clearBrowserCacheOnly error:', err);
        return false;
    }
}

// Try to reload the underlying Puppeteer pages used by whatsapp-web.js
// Attempts multiple access points to maintain compatibility with different versions.
async function reloadClientPages() {
    try {
        const pages = [];
        try { if (client && client.pupPage) pages.push(client.pupPage); } catch (e) { }
        try { if (client && client.page) pages.push(client.page); } catch (e) { }
        try { if (client && client._page) pages.push(client._page); } catch (e) { }
        try {
            if (client && client.browser && typeof client.browser.pages === 'function') {
                const pgs = await client.browser.pages(); if (Array.isArray(pgs)) pages.push(...pgs);
            }
        } catch (e) { }
        try {
            if (client && client.puppeteer && typeof client.puppeteer.pages === 'function') {
                const pgs = await client.puppeteer.pages(); if (Array.isArray(pgs)) pages.push(...pgs);
            }
        } catch (e) { }

        // Try client.getBrowser() as a last resort
        try {
            if (typeof client.getBrowser === 'function') {
                const b = await client.getBrowser(); if (b && typeof b.pages === 'function') {
                    const pgs = await b.pages(); if (Array.isArray(pgs)) pages.push(...pgs);
                }
            }
        } catch (e) { }

        const uniq = Array.from(new Set(pages.filter(Boolean)));
        if (!uniq.length) throw new Error('No Puppeteer pages found to reload');

        let succeeded = false;
        for (const p of uniq) {
            try {
                // Preferred API: page.reload()
                if (p && typeof p.reload === 'function') {
                    try { await p.reload({ waitUntil: 'networkidle0' }); succeeded = true; continue; } catch (e) { try { await p.reload(); succeeded = true; continue; } catch (e2) { /* fallback */ } }
                }

                // If page.goto + page.url available, navigate to same URL
                if (p && typeof p.url === 'function' && typeof p.goto === 'function') {
                    try {
                        const u = p.url();
                        if (u) { await p.goto(u, { waitUntil: 'networkidle0' }); succeeded = true; continue; }
                    } catch (e) { /* ignore */ }
                }

                // Fallback: evaluate a location.reload inside the page context
                if (p && typeof p.evaluate === 'function') {
                    try {
                        await p.evaluate(() => { try { location.reload(true); } catch (e) { try { location.reload(); } catch (e2) { /* ignore */ } } });
                        succeeded = true;
                        continue;
                    } catch (e) { /* ignore */ }
                }
            } catch (e) { /* try next page */ }
        }
        return succeeded;
    } catch (err) {
        console.error('reloadClientPages error:', err);
        return false;
    }
}

// Attempt to restart the Node process: spawn a replacement and exit.
// This emulates Ctrl+C then `node index.js` for the same argv.
async function restartProcess() {
    try {
        if (amLeader) {
            try { await DB.releaseLeader(LEADER_KEY, INSTANCE_ID); } catch (e) { /* ignore */ }
        }
    } catch (e) { /* ignore */ }

    try { await DB.publishChannel(HEARTBEAT_CHANNEL, { owner: null, ts: Date.now(), reason: 'reboot' }); } catch (e) { /* ignore */ }
    try { await DB.closeSubscriber(); } catch (e) { /* ignore */ }

    try {
        if (client && typeof client.destroy === 'function') {
            try { await client.destroy(); } catch (e) { /* ignore */ }
        }
    } catch (e) { /* ignore */ }

    try {
        const nodePath = process.execPath || 'node';
        const args = process.argv.slice(1);

        // Detect common PM2 environment variables
        const isPM2 = (typeof process.env.pm_id !== 'undefined') || !!process.env.PM2_HOME || !!process.env.PM2_PROCESS_NAME || !!process.env.PM2_PUBLIC_KEY;

        if (isPM2) {
            // If running under PM2, ask PM2 to restart this process by id/name
            const pmId = process.env.pm_id;
            const target = pmId ? pmId.toString() : (process.env.PM2_PROCESS_NAME || process.argv[1]);
            console.log('[reboot] detected PM2, requesting pm2 restart', target);
            const child = spawn('pm2', ['restart', target], { stdio: 'inherit', env: process.env, cwd: process.cwd() });
            // wait for pm2 command to complete (don't fail the reboot if pm2 returns non-zero)
            await new Promise((resolve) => {
                child.on('close', () => resolve());
                child.on('error', () => resolve());
            });
            console.log('[reboot] pm2 restart requested for', target);
        } else if (process.env.TMUX) {
            // Running inside a tmux session: spawn non-detached so the new process stays attached to the same session/window.
            const child = spawn(nodePath, args, { detached: false, stdio: 'inherit', env: process.env, cwd: process.cwd() });
            console.log('[reboot] spawned replacement process pid=', child && child.pid, '(tmux, not detached)');
        } else {
            // Default fallback: spawn detached so the replacement keeps running after we exit
            const child = spawn(nodePath, args, {
                detached: true,
                stdio: 'inherit',
                env: process.env,
                cwd: process.cwd()
            });
            try { child.unref(); } catch (e) { /* ignore */ }
            console.log('[reboot] spawned replacement process pid=', child && child.pid);
        }
    } catch (e) {
        console.error('[reboot] failed to spawn replacement process', e);
    }

    // allow logs to flush then exit
    setTimeout(() => process.exit(0), 200);
}

// === BEGIN PATCH: safe fallback for getContactById to avoid WA Web internal API break ===
(async () => {
    try {
        // keep original reference (only if present)
        const _origGetContactById = client.getContactById && client.getContactById.bind(client);
        if (_origGetContactById) {
            let _warnedOnce = false;
            client.getContactById = async (id) => {
                try {
                    return await _origGetContactById(id);
                } catch (err) {
                    // Be conservative: only apply fallback for known internal API break symptoms
                    const msg = String(err && err.message ? err.message : err).toString();
                    const lowered = msg.toLowerCase();
                    if (lowered.includes('getismycontact') || lowered.includes('contactmethods') || lowered.includes('getcontactmodel')) {
                        if (!_warnedOnce) {
                            _warnedOnce = true;
                            console.warn('Notice: getContactById threw internal WA-Web error, returning lightweight fallback contact. This may affect some contact fields. Err:', msg);
                        }

                        // Normalize id to string if caller passed an object
                        let serialized = id;
                        try {
                            if (id && typeof id === 'object') {
                                if (id._serialized) serialized = id._serialized;
                                else if (id.id && id.id._serialized) serialized = id.id._serialized;
                                else serialized = String(id);
                            }
                        } catch (e) { serialized = String(id); }

                        const uid = (typeof serialized === 'string') ? serialized : String(serialized);
                        const number = String(uid).split('@')[0];

                        // Return a more complete, Contact-like plain object so callers
                        // can still read commonly used properties without crashing.
                        return {
                            id: { _serialized: uid },
                            _serialized: uid,
                            number: number,
                            pushname: null,
                            formattedName: null,
                            shortName: number,
                            isMyContact: false,
                            isBusiness: false,
                            isEnterprise: false,
                        };
                    }
                    // rethrow unknown errors to avoid masking real problems
                    throw err;
                }
            };
        }
    } catch (e) {
        // fail-open: do nothing if patching fails
        console.error('Warning: failed to patch getContactById fallback:', e);
    }
})();
// === END PATCH ===

// Idle-clear configuration: when no command is received for this period,
// clear the chat history for all groups as visible to the bot (only clears
// messages for the bot's local view). Timer is reset when a command is seen.
const IDLE_CLEAR_MS = 3 * 60 * 1000; // 3 minutes
let _idleClearTimer = null;

// Simple in-memory job queue to offload non-urgent background tasks
const _jobQueue = [];
let _jobWorkerRunning = false;
function enqueueJob(type, payload) {
    _jobQueue.push({ type, payload });
    _runJobWorker().catch(e => console.error('Job worker error:', e));
}

async function _runJobWorker() {
    if (_jobWorkerRunning) return;
    _jobWorkerRunning = true;
    while (_jobQueue.length) {
        const job = _jobQueue.shift();
        try {
            if (!job) continue;
            if (job.type === 'idle-clear') {
                // call the clear function but yield between each chat to avoid blocking
                try { await clearAllGroupChatsForBot(); } catch (e) { console.error('idle-clear job failed:', e); }
            } else if (job.type === 'backup') {
                try {
                    const payload = job.payload || {};
                    const res = await backupRedisToFile();
                    const notify = `✅ Backup selesai: ${res.filename}\nKunci: ${res.count}\nUkuran: ${res.size} bytes`;
                    if (payload && payload.chatId) await sendQueue(payload.chatId, notify, undefined, 'high');
                } catch (e) {
                    console.error('backup job failed:', e);
                    try { if (job.payload && job.payload.chatId) await sendQueue(job.payload.chatId, '❌ Backup gagal: ' + (e && e.message ? e.message : String(e))); } catch (e2) { /* ignore */ }
                }
            } else {
                // unknown job type: ignore for now
            }
        } catch (e) {
            console.error('Error processing job', job && job.type, e);
        }
        // small yield to event loop between jobs
        await new Promise(r => setTimeout(r, 50));
    }
    _jobWorkerRunning = false;
}

// Build redis client options from env (same defaults as DB._buildRedisOptions)
function _buildRedisOptionsForBackup() {
    const host = process.env.REDIS_HOST || 'redis-10092.c52.us-east-1-4.ec2.cloud.redislabs.com';
    const port = Number(process.env.REDIS_PORT || 10092);
    const username = process.env.REDIS_USERNAME || 'default';
    const password = process.env.REDIS_PASSWORD || 'xTcF2J1F1VoPiwyg9CBcc4fzYMG4IP4W';
    const tls = (String(process.env.REDIS_TLS || '').toLowerCase() === 'true');
    const socket = { host, port };
    if (tls) socket.tls = true;
    const opt = { username, password, socket };
    return opt;
}

// Perform a full logical backup by scanning all keys and exporting their type/value to a JSON file
async function backupRedisToFile() {
    const clientTmp = createRedisClient(_buildRedisOptionsForBackup());
    await clientTmp.connect();
    const out = [];
    let count = 0;
    try {
        if (typeof clientTmp.scanIterator === 'function') {
            for await (const rawKey of clientTmp.scanIterator({ MATCH: '*', COUNT: 200 })) {
                // scanIterator may (in some client versions) yield arrays/batches; normalize
                const keysBatch = Array.isArray(rawKey) ? rawKey : [rawKey];
                for (const kRaw of keysBatch) {
                    const key = (kRaw && kRaw.toString) ? kRaw.toString() : kRaw;
                    try {
                        const type = await clientTmp.type(key).catch(() => 'string');
                        const pttl = await clientTmp.pTTL(key).catch(() => -1);
                        const ttl = (typeof pttl === 'number') ? pttl : -1;
                        let value = null;
                        if (type === 'string') value = await clientTmp.get(key).catch(() => null);
                        else if (type === 'hash') value = await clientTmp.hGetAll(key).catch(() => null);
                        else if (type === 'list') value = await clientTmp.lRange(key, 0, -1).catch(() => null);
                        else if (type === 'set') value = await clientTmp.sMembers(key).catch(() => null);
                        else if (type === 'zset') value = await clientTmp.zRangeWithScores ? await clientTmp.zRangeWithScores(key, 0, -1).catch(() => null) : await clientTmp.zRange(key, 0, -1).catch(() => null);
                        else value = await clientTmp.get(key).catch(() => null);
                        out.push({ key, type, ttl, value });
                        count++;
                    } catch (e) {
                        console.error('Failed to backup key', key, e);
                    }
                }
            }
        } else {
            // fallback to KEYS (may block on large DBs)
            const keys = await clientTmp.keys('*');
            for (const key of keys) {
                try {
                    const type = await clientTmp.type(key).catch(() => 'string');
                    const pttl = await clientTmp.pTTL(key).catch(() => -1);
                    const ttl = (typeof pttl === 'number') ? pttl : -1;
                    let value = null;
                    if (type === 'string') value = await clientTmp.get(key).catch(() => null);
                    else if (type === 'hash') value = await clientTmp.hGetAll(key).catch(() => null);
                    else if (type === 'list') value = await clientTmp.lRange(key, 0, -1).catch(() => null);
                    else if (type === 'set') value = await clientTmp.sMembers(key).catch(() => null);
                    else if (type === 'zset') value = await clientTmp.zRangeWithScores ? await clientTmp.zRangeWithScores(key, 0, -1).catch(() => null) : await clientTmp.zRange(key, 0, -1).catch(() => null);
                    else value = await clientTmp.get(key).catch(() => null);
                    out.push({ key, type, ttl, value });
                    count++;
                } catch (e) {
                    console.error('Failed to backup key', key, e);
                }
            }
        }

        const ts = new Date();
        const stamp = ts.toISOString().replace(/[:.]/g, '-');
        const filename = `redis-backup-${stamp}.json`;
        const filepath = path.join(process.cwd(), filename);
        await fs.promises.writeFile(filepath, JSON.stringify({ createdAt: ts.toISOString(), keyCount: count, data: out }, null, 2));
        const stats = await fs.promises.stat(filepath);
        await clientTmp.disconnect();
        return { filename, filepath, count, size: stats.size };
    } catch (e) {
        try { await clientTmp.disconnect(); } catch (e2) { /* ignore */ }
        throw e;
    }
}

// --- Contact lookup cache (simple TTL LRU-ish) ---
const _contactCache = new Map();
const CONTACT_CACHE_TTL = Number(process.env.CONTACT_CACHE_TTL_MS || 30000);
const CONTACT_CACHE_MAX = Number(process.env.CONTACT_CACHE_MAX || 2000);
function _normalizeUid(uid) {
    if (!uid) return null;
    if (typeof uid === 'object') {
        if (uid._serialized) return uid._serialized;
        if (uid.id && uid.id._serialized) return uid.id._serialized;
        try { return String(uid); } catch (e) { return null; }
    }
    return String(uid);
}

async function getContactCached(uid) {
    try {
        const id = _normalizeUid(uid);
        if (!id) return null;
        const now = Date.now();
        const ent = _contactCache.get(id);
        if (ent && ent.expires > now) {
            return ent.value;
        }
        // fetch fresh
        const contact = await client.getContactById(id);
        if (!contact) return null;
        // maintain cache size
        if (_contactCache.size >= CONTACT_CACHE_MAX) {
            // simple eviction: remove oldest (first key)
            const firstKey = _contactCache.keys().next().value;
            if (firstKey) _contactCache.delete(firstKey);
        }
        _contactCache.set(id, { value: contact, expires: now + CONTACT_CACHE_TTL });
        return contact;
    } catch (e) {
        return null;
    }
}

// --- Preload frequently used assets (MessageMedia) ---
const preloadedMedia = { qris: null };
(async function preloadAssets() {
    try {
        const imgPath = path.join(__dirname, 'qris.png');
        const data = await fs.promises.readFile(imgPath).catch(() => null);
        if (data) {
            const base64 = data.toString('base64');
            try {
                preloadedMedia.qris = new MessageMedia('image/png', base64, 'qris.png');
            } catch (e) {
                preloadedMedia.qris = null;
            }
        }
    } catch (e) {
        preloadedMedia.qris = null;
    }
})();

function isCommandText(text) {
    try {
        if (!text) return false;
        const t = String(text).trim();
        // treat dot-prefixed messages as commands OR a single-symbol prefix
        // followed by letters (e.g. !gass, #cmd). This ensures such commands
        // reset the idle-clear timer as well.
        return t.startsWith('.') || (/^[^A-Za-z0-9\s][A-Za-z].*/.test(t));
    } catch (e) { return false; }
}

async function clearAllGroupChatsForBot() {
    try {
        console.log('[idle-clear] Starting clear of all group chats for bot');
        // attempt to get all chats from the client
        let chats = [];
        try { chats = await client.getChats(); } catch (e) { console.error('[idle-clear] client.getChats failed:', e); return; }

        // chats may be a Collection or an Array
        const list = Array.isArray(chats) ? chats : (typeof chats.values === 'function' ? Array.from(chats.values()) : []);

        for (const ch of list) {
            try {
                if (!ch) continue;
                // some chat objects expose isGroup flag
                if (ch.isGroup || ch.fetchMessages) {
                    // Best-effort: try the Chat.clearMessages() API which clears messages
                    // from the client's local view. If method missing, skip gracefully.
                    if (typeof ch.clearMessages === 'function') {
                        try {
                            await ch.clearMessages();
                            console.log(`[idle-clear] Cleared chat ${ch.id && ch.id._serialized ? ch.id._serialized : ch.id || ch}`);
                        } catch (e) {
                            console.error('[idle-clear] clearMessages failed for', ch.id && ch.id._serialized, e);
                        }
                    } else if (typeof client.clearChat === 'function') {
                        try {
                            const id = (ch.id && ch.id._serialized) || ch.id || null;
                            if (id) await client.clearChat(id);
                            console.log(`[idle-clear] Cleared chat (client.clearChat) ${id}`);
                        } catch (e) {
                            console.error('[idle-clear] client.clearChat failed for', ch.id && ch.id._serialized, e);
                        }
                    }
                }
            } catch (e) {
                console.error('[idle-clear] error iterating chats:', e);
            }
            // small delay to avoid hammering the underlying session
            await new Promise(r => setTimeout(r, 200));
        }
        console.log('[idle-clear] finished');
    } catch (e) {
        console.error('[idle-clear] unexpected error:', e);
    }
}

function _clearIdleTimer() {
    try { if (_idleClearTimer) { clearTimeout(_idleClearTimer); _idleClearTimer = null; } } catch (e) { /* ignore */ }
}

function resetIdleClearTimer() {
    try {
        _clearIdleTimer();
        _idleClearTimer = setTimeout(() => {
            try { enqueueJob('idle-clear', {}); } catch (e) { console.error('[idle-clear] enqueue failed:', e); }
            _idleClearTimer = null;
        }, IDLE_CLEAR_MS);
    } catch (e) { console.error('[idle-clear] failed to reset timer:', e); }
}

client.on('qr', qr => {
    // Only leader should handle QR (standby must not interfere)
    if (!amLeader) return;
    console.log("Scan QR berikut:");
    qrcode.generate(qr, { small: true });
});

client.on('message', async msg => {
    // Optimization: Ignore messages from self
    if (msg.fromMe) return;

    // Optimization: Ignore media messages if not needed (as per user suggestion)
    // You can comment this out if you need to process media commands like sticker makers
    if (msg.hasMedia) return;

    // Only respond in groups; optionally restrict to allowed groups list
    if (!msg.from || !msg.from.endsWith('@g.us')) return;
    try {
        if (GROUP_FILTER_ENABLED && Array.isArray(ALLOWED_GROUPS) && ALLOWED_GROUPS.length) {
            if (!ALLOWED_GROUPS.includes(msg.from)) return;
        }
    } catch (e) {
        // If something goes wrong with the filter, fail-open (allow processing)
        console.error('Error evaluating group filter:', e);
    }

    // Fast guard: only leader should process messages to avoid split-brain
    if (!amLeader) {
        // Standby: do not process messages, but remain alive and monitoring
        console.log('[leader] standby - waiting for leader to stop/crash before taking over');
        return;
    }

    const chat = await msg.getChat();

    // Determine sender id reliably using getContact()
    const contact = await msg.getContact();
    const senderId = (contact && contact.id && contact.id._serialized) ? contact.id._serialized : (msg.author || msg.from);
    const senderNumber = senderId.split('@')[0];

    // Load registrations
    const regs = loadRegistrations();

    const body = (msg.body || '').trim();
    // Persist a minimal inflight marker so takeover can claim uncompleted commands
    const inflightKey = `inflight:${INSTANCE_ID}:${(msg && msg.id && (msg.id._serialized || msg.id)) || (msg.timestamp || Date.now())}:${senderNumber}`;
    let _inflightSet = false;
    try {
        try {
            await DB.setInflight(inflightKey, {
                instance: INSTANCE_ID,
                chatId: (chat && chat.id && chat.id._serialized) || null,
                sender: senderNumber,
                body,
                ts: Date.now(),
                stage: 'received'
            }, 30 * 1000);
            _inflightSet = true;
        } catch (e) { console.error('setInflight failed', e); }
        // If this message is a command, reset the idle-clear timer so we don't
        // clear chats while the bot is being actively used.
        try { if (isCommandText(body)) resetIdleClearTimer(); } catch (e) { /* ignore */ }
        // Link detection: if message contains an URL (http(s):// or www.), delete message,
        // issue a warning, store it in warn.json and kick user on 3 warnings. Admins are excluded.
        try {
            const urlRegex = /(?:https?:\/\/|www\.)[^\s]+/i;
            if (urlRegex.test(body)) {
                try {
                    const senderIsAdmin = await isSenderAdmin(chat, senderId);
                    if (senderIsAdmin) {
                        // admins may post links without warnings
                    } else {
                        // non-admin: delete + warn
                        let botSerialized = null;
                        try {
                            if (client && client.info) {
                                if (client.info.wid && client.info.wid._serialized) botSerialized = client.info.wid._serialized;
                                else if (client.info.me && client.info.me._serialized) botSerialized = client.info.me._serialized;
                            }
                        } catch (e) { /* ignore */ }

                        if (botSerialized && senderId === botSerialized) {
                            // from bot itself - ignore
                        } else {
                            try { await msg.delete(true); } catch (e) { /* ignore delete errors */ }
                            const newCount = addWarning(senderNumber);
                            const warnText = `⚠️ *Warning*: Dilarang mengirimkan link/promosi sesuai ketentuan grup.\n🚨 *Pelanggaran*: Anda memiliki ${newCount} pelanggaran. Jika 3 kali melanggar akan otomatis di-kick oleh sistem.`;
                            const mentionId = ensureSerializedId(senderId || senderNumber);
                            if (mentionId) {
                                try { await sendQueue(chat.id._serialized, warnText, { mentions: [mentionId] }); } catch (e) { try { await sendQueue(chat.id._serialized, warnText); } catch (e2) { /* ignore */ } }
                            } else {
                                try { await sendQueue(chat.id._serialized, warnText); } catch (e) { /* ignore */ }
                            }

                            if (newCount >= 3) {
                                try {
                                    await chat.removeParticipants([senderId]);
                                    const kickedMsg = mentionId ? `🚫 @${mentionId.split('@')[0]} telah di-kick karena mencapai 3 pelanggaran.` : `🚫 ${senderNumber} telah di-kick karena mencapai 3 pelanggaran.`;
                                    if (mentionId) await sendQueue(chat.id._serialized, kickedMsg, { mentions: [mentionId] }); else await sendQueue(chat.id._serialized, kickedMsg);
                                } catch (e) { console.error('Gagal mengeluarkan peserta yang melanggar:', e); }
                            }
                            return;
                        }
                    }
                } catch (e) {
                    console.error('Error in link-detection admin-check fallback:', e);
                }
            }
        } catch (e) { /* ignore link-detection top-level errors */ }

        // Handle .regis command (admin-only)
        if (body.toLowerCase().startsWith('.regis')) {
            // Check admin status (robust)
            const isAdmin = await isSenderAdmin(chat, senderId);

            if (!isAdmin) {
                replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high');
                return;
            }



            // Parse number or mention after command
            const parts = body.split(/\s+/);
            if (parts.length < 2) {
                replyQueue(msg, 'Gunakan: .regis 6281234567890 atau tag pengguna: .regis @pengguna', undefined, 'high');
                return;
            }

            // If admin mentioned a user, prefer the mentioned uid/number
            const targetObj = await getMentionedTarget(msg, body);
            let rawNum = null;
            let uid = null;
            if (targetObj && (targetObj.number || targetObj.uid)) {
                rawNum = targetObj.number || null;
                uid = targetObj.uid || null;
                // Normalize uid to include domain if missing (store as e.g. 628123..@c.us)
                if (uid && !uid.includes('@')) {
                    uid = uid + '@c.us';
                }
            } else {
                // Keep only digits from the provided token
                rawNum = parts[1].replace(/[^0-9]/g, '');
                // If admin provided a plain number, try to resolve its uid via client
                try {
                    const tryUid = `${rawNum}@c.us`;
                    const contact = await getContactCached(tryUid);
                    if (contact && contact.id && contact.id._serialized) {
                        uid = contact.id._serialized;
                    }
                } catch (e) {
                    // ignore if cannot resolve
                }
            }

            if (!rawNum || !/^(?:62|1)\d{6,}$/.test(rawNum)) {
                replyQueue(msg, 'Nomor tidak valid. Pastikan menggunakan kode negara, contoh: 6281234567890 atau 11234567890, atau tag pengguna.', undefined, 'high');
                return;
            }

            const exists = regs.find(r => r.number === rawNum || (uid && (r.uid === uid || r.uid === (uid.replace(/@c\.us$/, '')) || (r.uid && r.uid.replace(/@c\.us$/, '') === uid.replace(/@c\.us$/, '')))));
            if (exists) {
                // If entry exists by number but missing uid, and we have uid now, attach it silently
                if (uid && !exists.uid) {
                    await withRegistrationsLock(async (regsNow) => {
                        const e = regsNow.find(r => r.number === rawNum);
                        if (e) e.uid = uid;
                    });
                }
                replyQueue(msg, '✅ Player sudah terdaftar!', undefined, 'high');
                return;
            }

            const entry = {
                number: rawNum,
                uid: uid || undefined,
                addedBy: senderNumber,
                addedAt: new Date().toISOString(),
                balance: 0
            };
            await withRegistrationsLock(async (regsNow) => {
                regsNow.push(entry);
            });
            // Ensure in-process registrations cache is invalidated so new member
            // is immediately visible to subsequent commands in this process.
            try { invalidateRegsCache(); } catch (e) { /* ignore */ }
            replyQueue(msg, `✅ Berhasil menambahkan player: ${rawNum}`, undefined, 'high');
            return;
        }

        // Handle .unregis command (admin-only) - remove a registered number
        if (body.toLowerCase().startsWith('.unregis')) {
            const isAdminNow = await isSenderAdmin(chat, senderId);
            if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

            const partsU = body.split(/\s+/);
            if (partsU.length < 2) { replyQueue(msg, 'Gunakan: .unregis 6281234567890 atau tag pengguna: .unregis @pengguna', undefined, 'high'); return; }

            const targetObjU = await getMentionedTarget(msg, body);
            let rawNumU = null;
            let uidU = null;
            if (targetObjU && (targetObjU.number || targetObjU.uid)) {
                rawNumU = targetObjU.number || null;
                uidU = targetObjU.uid || null;
                if (uidU && !uidU.includes('@')) uidU = uidU + '@c.us';
            } else {
                rawNumU = partsU[1].replace(/[^0-9]/g, '');
                try {
                    const tryUid = `${rawNumU}@c.us`;
                    const contactU = await getContactCached(tryUid);
                    if (contactU && contactU.id && contactU.id._serialized) uidU = contactU.id._serialized;
                } catch (e) { /* ignore */ }
            }

            if (!rawNumU || !/^(?:62|1)\d{6,}$/.test(rawNumU)) { replyQueue(msg, 'Nomor tidak valid. Pastikan menggunakan kode negara, contoh: 6281234567890 atau tag pengguna.', undefined, 'high'); return; }

            // Remove if present
            let removed = false;
            await withRegistrationsLock(async (regsNow) => {
                const idx = regsNow.findIndex(r => r.number === rawNumU || (uidU && (r.uid === uidU || r.uid === (uidU.replace(/@c\.us$/, '')))));
                if (idx >= 0) {
                    regsNow.splice(idx, 1);
                    removed = true;
                }
            });
            try { invalidateRegsCache(); } catch (e) { /* ignore */ }
            if (removed) replyQueue(msg, `✅ Berhasil menghapus player: ${rawNumU}`, undefined, 'high'); else replyQueue(msg, `❌ Nomor ${rawNumU} tidak ditemukan di daftar registrasi.`, undefined, 'high');
            return;
        }

        // Handle .hapuscache - admin only: clear browser cache (without cookies)
        if (body.toLowerCase().startsWith('.hapuscache')) {
            try {
                const isAdminNow2 = await isSenderAdmin(chat, senderId);
                if (!isAdminNow2) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }
                replyQueue(msg, '🔄 Menjalankan pembersihan cache browser (tanpa cookie). Mohon tunggu...');
                const ok = await clearBrowserCacheOnly();
                // Trigger GC if available to help free memory after cache clear
                if (typeof global.gc === 'function') {
                    try { global.gc(); } catch (e) { /* ignore */ }
                }
                if (ok) replyQueue(msg, '✅ Cache browser dibersihkan. Performa mungkin membaik dalam beberapa detik.', undefined, 'high');
                else replyQueue(msg, '❌ Gagal membersihkan cache (halaman Puppeteer tidak ditemukan atau terjadi error).', undefined, 'high');
            } catch (e) {
                console.error('Error handling .hapuscache:', e);
                replyQueue(msg, '❌ Terjadi kesalahan saat mencoba membersihkan cache.', undefined, 'high');
            }
            return;
        }

        // Handle .reboot - admin only: countdown messages then reload page(s)
        if (body.toLowerCase().startsWith('.reboot')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const gid = (chat && chat.id && chat.id._serialized) ? chat.id._serialized : msg.from;

                // Countdown 5..1 with 1 second interval per message
                for (let i = 5; i >= 1; i--) {
                    try {
                        await sendQueue(gid, `🔃 *System restart mulai dalam ${i}*`);
                    } catch (e) {
                        try { await sendQueue(gid, `🔃 *System restart mulai dalam ${i}*`); } catch (e2) { /* ignore */ }
                    }
                    // wait 1 second
                    await new Promise(res => setTimeout(res, 1000));
                }

                // Instead of reloading browser pages, spawn a new Node process
                try {
                    await sendQueue(gid, '💪 *Restarting system now...*');
                } catch (e) { /* ignore */ }
                try {
                    await restartProcess();
                    // process will exit; if it does not, notify admin after brief delay
                    await new Promise(res => setTimeout(res, 1000));
                    try { await sendQueue(gid, '✅ Restart sequence attempted. If process did not stop, manual restart may be required.'); } catch (e) { /* ignore */ }
                } catch (e) {
                    console.error('Error during .reboot restartProcess:', e);
                    try { await sendQueue(gid, '❌ Gagal memulai ulang proses: ' + (e && e.message ? e.message : String(e))); } catch (e2) { /* ignore */ }
                }
            } catch (e) {
                console.error('Error handling .reboot:', e);
                replyQueue(msg, '❌ Terjadi kesalahan saat mencoba reboot sistem.', undefined, 'high');
            }
            return;
        }

        // .listadmin - show list of admins in this group (accessible to everyone)
        if (body.toLowerCase() === '.listadmin') {
            try {
                // Use chat.participants first, fallback to chat.getAdmins()
                let adminIds = [];
                if (chat && Array.isArray(chat.participants)) {
                    adminIds = chat.participants
                        .filter(p => p && (p.isAdmin === true || p.isSuperAdmin === true || p.role === 'admin' || p.role === 'superadmin' || p.isAdmin === 'admin' || p.isAdmin === 'superadmin'))
                        .map(p => (p.id && p.id._serialized) || null)
                        .filter(Boolean);
                }

                if (adminIds.length === 0 && chat && typeof chat.getAdmins === 'function') {
                    const admins = await chat.getAdmins();
                    adminIds = admins.map(a => (a.id && a.id._serialized) || null).filter(Boolean);
                }

                // Exclude the bot's own number from the returned admin list to avoid confusion
                try {
                    let botSerialized = null;
                    if (client && client.info) {
                        if (client.info.wid && client.info.wid._serialized) botSerialized = client.info.wid._serialized;
                        else if (client.info.me && client.info.me._serialized) botSerialized = client.info.me._serialized;
                    }
                    if (botSerialized) {
                        adminIds = adminIds.filter(id => id !== botSerialized);
                    }
                } catch (e) { /* ignore */ }

                if (!adminIds || adminIds.length === 0) {
                    replyQueue(msg, 'Tidak dapat menemukan admin grup.', undefined, 'high');
                    return;
                }

                // Ensure serialized ids and build message with mentions
                const mentionIds = adminIds.map(id => ensureSerializedId(id)).filter(Boolean);
                const lines = [];
                lines.push('👨🏻‍⚖️💻 *Daftar Admin Sistem*\n');
                for (const m of mentionIds) {
                    const disp = `@${m.split('@')[0]}`;
                    let statusText = null;
                    try {
                        if (DB && typeof DB.getAdminStatus === 'function') {
                            statusText = await DB.getAdminStatus(m);
                        }
                    } catch (e) { /* ignore */ }
                    if (statusText) {
                        lines.push(`▪️ ${disp} - [${statusText}]`);
                    } else {
                        lines.push(`▪️ ${disp}`);
                    }
                }

                const message = lines.join('\n');
                if (mentionIds.length) replyQueue(msg, message, { mentions: mentionIds }, 'high'); else replyQueue(msg, message, undefined, 'high');
            } catch (e) {
                console.error('Error listing admins:', e);
                replyQueue(msg, 'Terjadi kesalahan saat mengambil daftar admin.', undefined, 'high');
            }
            return;
        }

        // .setstatus - admin only: set a short status string visible in .listadmin
        if (body.toLowerCase().startsWith('.setstatus')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                let status = body.trim().replace(/^\.setstatus\s*/i, '').trim();
                if (!status) { replyQueue(msg, 'Gunakan: .setstatus [status]\nContoh: .setstatus [online]', undefined, 'high'); return; }
                // Strip surrounding brackets if present
                if (status.startsWith('[') && status.endsWith(']')) status = status.slice(1, -1).trim();

                const who = (typeof ensureSerializedId === 'function') ? ensureSerializedId(senderId) : senderId;
                let ok = false;
                try {
                    if (DB && typeof DB.setAdminStatus === 'function') {
                        ok = await DB.setAdminStatus(who, status);
                    }
                } catch (e) { console.error('Error saving admin status:', e); }

                if (ok) replyQueue(msg, `✅ Status disimpan: [${status}]`, undefined, 'high'); else replyQueue(msg, `⚠️ Gagal menyimpan status (penyimpanan tidak tersedia).`, undefined, 'high');
            } catch (e) {
                console.error('Error handling .setstatus:', e);
                replyQueue(msg, 'Terjadi kesalahan saat menyimpan status.', undefined, 'high');
            }
            return;
        }

        // .listinflights - admin only: show current inflight keys and stages
        if (body.toLowerCase() === '.listinflights') {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }
                if (!DB || typeof DB.getInflights !== 'function') { replyQueue(msg, 'Fitur tidak tersedia (DB tidak mendukung).', undefined, 'high'); return; }
                const inflights = await DB.getInflights('inflight:*');
                const keys = Object.keys(inflights || {});
                if (!keys.length) { replyQueue(msg, 'Tidak ada inflight keys saat ini.', undefined, 'high'); return; }
                const lines = [];
                lines.push('📌 *Inflight Keys* (showing up to 100)\n');
                let count = 0;
                for (const k of keys) {
                    if (count++ > 100) break;
                    const v = inflights[k];
                    const stage = (v && v.stage) ? v.stage : '(unknown)';
                    const basic = `• ${k} — ${stage}`;
                    let detail = '';
                    try { detail = v && Object.keys(v).length ? ` ${JSON.stringify({ sender: v.sender, chatId: v.chatId, ts: v.ts }).slice(0, 200)}` : ''; } catch (e) { detail = ''; }
                    lines.push(basic + detail);
                }
                replyQueue(msg, lines.join('\n'), undefined, 'low');
            } catch (e) {
                console.error('Error handling .listinflights:', e);
                replyQueue(msg, 'Terjadi kesalahan saat mengambil inflight keys.', undefined, 'high');
            }
            return;
        }

        // .backupdb - admin only: create logical backup of Redis into JSON file in working dir
        if (body.toLowerCase() === '.backupdb') {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }
                replyQueue(msg, '🔄 Memulai backup Redis. File akan disimpan di direktori kerja proses (sama dengan tempat menjalankan index.js). Mohon tunggu.');
                enqueueJob('backup', { chatId: (chat && chat.id && chat.id._serialized) || msg.from, initiatedBy: senderNumber });
            } catch (e) {
                console.error('Error starting backup job:', e);
                replyQueue(msg, '❌ Gagal memulai backup: ' + (e && e.message ? e.message : String(e)), undefined, 'high');
            }
            return;
        }

        // .tagall - admin only: mention all participants with a custom message
        if (body.toLowerCase().startsWith('.tagall')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const text = body.trim().replace(/^\.tagall\s*/i, '').trim();
                if (!text) { replyQueue(msg, 'Gunakan: .tagall [pesan]', undefined, 'high'); return; }

                // Collect mention ids from chat participants
                let mentionIds = [];
                try {
                    if (chat && Array.isArray(chat.participants) && chat.participants.length) {
                        mentionIds = chat.participants.map(p => {
                            if (!p) return null;
                            const id = (p.id && p.id._serialized) || (p.id && p.id.user && `${p.id.user}@c.us`);
                            return ensureSerializedId(id);
                        }).filter(Boolean);
                    }
                } catch (e) {
                    mentionIds = [];
                }

                // Deduplicate and exclude the bot itself
                try {
                    let botSerialized = null;
                    if (client && client.info) {
                        if (client.info.wid && client.info.wid._serialized) botSerialized = client.info.wid._serialized;
                        else if (client.info.me && client.info.me._serialized) botSerialized = client.info.me._serialized;
                    }
                    mentionIds = Array.from(new Set(mentionIds || []));
                    if (botSerialized) mentionIds = mentionIds.filter(id => id !== botSerialized);
                } catch (e) { /* ignore */ }

                if (mentionIds.length) {
                    await sendQueue(chat.id._serialized, text, { mentions: mentionIds }, 'low');
                } else {
                    await sendQueue(chat.id._serialized, text, undefined, 'low');
                }
            } catch (e) {
                console.error('Error handling .tagall:', e);
                replyQueue(msg, 'Terjadi kesalahan saat menjalankan .tagall.', undefined, 'high');
            }
            return;
        }

        // .jid - admin only: show current group JID
        if (body.toLowerCase() === '.jid') {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }
                const gid = (chat && chat.id && chat.id._serialized) ? chat.id._serialized : msg.from;
                replyQueue(msg, `JID grup saat ini: ${gid}`, undefined, 'high');
            } catch (e) {
                console.error('Error handling .jid:', e);
                replyQueue(msg, 'Terjadi kesalahan saat mendapatkan JID grup.', undefined, 'high');
            }
            return;
        }

        // .groupfilter - admin only: toggle group response restriction and manage allowed JIDs
        if (body.toLowerCase().startsWith('.groupfilter')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const parts = body.trim().split(/\s+/);
                if (parts.length === 1) {
                    const list = (Array.isArray(ALLOWED_GROUPS) && ALLOWED_GROUPS.length) ? ALLOWED_GROUPS.join(', ') : '(kosong)';
                    replyQueue(msg, `Group filter: ${GROUP_FILTER_ENABLED ? 'ON' : 'OFF'}\nAllowed groups: ${list}\nUsage: .groupfilter on|off|add <jid>|remove <jid>`, undefined, 'high');
                    return;
                }

                const cmd = (parts[1] || '').toLowerCase();
                if (cmd === 'on' || cmd === 'true') {
                    GROUP_FILTER_ENABLED = true;
                    replyQueue(msg, 'Group filter diaktifkan.', undefined, 'high');
                    return;
                }
                if (cmd === 'off' || cmd === 'false') {
                    GROUP_FILTER_ENABLED = false;
                    replyQueue(msg, 'Group filter dinonaktifkan.', undefined, 'high');
                    return;
                }
                if (cmd === 'add' && parts[2]) {
                    const gid = parts[2];
                    if (!gid.endsWith('@g.us')) { replyQueue(msg, 'Format JID harus berakhiran @g.us', undefined, 'high'); return; }
                    if (!ALLOWED_GROUPS.includes(gid)) ALLOWED_GROUPS.push(gid);
                    replyQueue(msg, `Menambahkan ${gid} ke daftar allowed groups.`, undefined, 'high');
                    return;
                }
                if (cmd === 'remove' && parts[2]) {
                    const gid = parts[2];
                    ALLOWED_GROUPS = (ALLOWED_GROUPS || []).filter(x => x !== gid);
                    replyQueue(msg, `Menghapus ${gid} dari daftar allowed groups.`, undefined, 'high');
                    return;
                }

                replyQueue(msg, 'Perintah tidak dikenal. Gunakan: on|off|add <jid>|remove <jid>', undefined, 'high');
            } catch (e) {
                console.error('Error handling .groupfilter:', e);
                replyQueue(msg, 'Terjadi kesalahan saat memproses .groupfilter.', undefined, 'high');
            }
            return;
        }

        // .cancelpvp - admin only: manual cancel a PvP room and refund stakes
        if (body.toLowerCase().startsWith('.cancelpvp')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const parts = body.trim().split(/\s+/);
                if (parts.length < 2) { replyQueue(msg, 'Penggunaan: .cancelpvp [kode_room]', undefined, 'high'); return; }
                const code = parts[1];
                const room = await loadPvpRoom(code);
                if (!room) { replyQueue(msg, `Room pvp ${code} tidak ditemukan.`, undefined, 'high'); return; }

                // Ensure room belongs to this group (safety)
                const gid = (chat && chat.id && chat.id._serialized) ? chat.id._serialized : msg.from;
                if (room.groupId && room.groupId !== gid) {
                    replyQueue(msg, 'Room ini tidak berada di grup ini.', undefined, 'high');
                    return;
                }

                // Refund logic: attempt to refund per-player stake (room.totalbet)
                try {
                    const tb = Number(room.totalbet || 0);
                    if (tb > 0) {
                        if (DB && typeof DB.atomicReleaseBalance === 'function') {
                            // If waiting, refund creator only
                            if (room.status === 'waiting' || !Array.isArray(room.participants) || room.participants.length === 0) {
                                await DB.atomicReleaseBalance(room.creator, tb);
                                invalidateRegsCache();
                            } else {
                                for (const p of room.participants) {
                                    if (!p || !p.number) continue;
                                    await DB.atomicReleaseBalance(p.number, tb).catch(() => null);
                                }
                                invalidateRegsCache();
                            }
                        } else {
                            // Fallback to registrations lock flow
                            await withRegistrationsLock(async (regsNow) => {
                                // If waiting (only creator reserved), refund creator
                                if (room.status === 'waiting' || !Array.isArray(room.participants) || room.participants.length === 0) {
                                    const creator = regsNow.find(r => r.number === room.creator);
                                    if (creator && tb > 0) creator.balance = Number(creator.balance || 0) + tb;
                                    return;
                                }

                                // Active or partially filled: refund each participant their per-player bet
                                for (const p of room.participants) {
                                    if (!p || !p.number) continue;
                                    const reg = regsNow.find(r => r.number === p.number);
                                    if (!reg) continue;
                                    if (tb > 0) reg.balance = Number(reg.balance || 0) + tb;
                                }
                            });
                        }
                    }
                } catch (e) {
                    console.error('Gagal mereset saldo saat cancelpvp:', e);
                }

                // Notify group and mention participants if possible
                try {
                    const pArr = Array.isArray(room.participants) && room.participants.length ? room.participants : [{ number: room.creator, uid: room.creatorUid }];
                    const mentions = [];
                    for (const p of pArr) {
                        if (!p) continue;
                        const id = ensureSerializedId(p.uid || p.number);
                        if (id) mentions.push(id);
                    }
                    const notify = `⚠️ *Room PVP ${code} dibatalkan oleh admin.*\nSaldo taruhan telah dikembalikan ke peserta.`;
                    if (mentions.length) sendQueue(gid, notify, { mentions }); else sendQueue(gid, notify);
                } catch (e) {
                    console.error('Gagal mengirim notifikasi cancelpvp:', e);
                }

                // Cleanup: delete file and clear timers
                try {
                    await deletePvpRoomFile(code);
                    clearActiveTimer(code);
                    if (pvpRoomTimeouts.has(code)) { clearTimeout(pvpRoomTimeouts.get(code)); pvpRoomTimeouts.delete(code); }
                } catch (e) { /* ignore */ }

                return;
            } catch (e) {
                console.error('Error handling .cancelpvp:', e);
                replyQueue(msg, 'Terjadi kesalahan saat memproses .cancelpvp.', undefined, 'high');
                return;
            }
        }

        // Handle admin-only balance commands (including .top) before enforcing registration
        const lower = body.toLowerCase();
        if (lower.startsWith('.addbal') || lower.startsWith('.removebal') || lower.startsWith('.cekbal') || lower.startsWith('.top')) {
            const isAdmin = await isSenderAdmin(chat, senderId);
            if (!isAdmin) {
                replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high');
                return;
            }

            // Admin-only: show top balances leaderboard
            if (lower === '.top') {
                try {
                    if (!Array.isArray(regs) || regs.length === 0) {
                        replyQueue(msg, 'Belum ada pengguna yang teregistrasi.', undefined, 'high');
                        return;
                    }
                    const sorted = [...regs].sort((a, b) => (Number(b.balance || 0) - Number(a.balance || 0)));
                    const top = sorted.slice(0, 10);

                    const mentions = [];
                    const lines = [];
                    lines.push('🏆 *TOP 10 PLAYER SALDO TERTINGGI* 🏆\n');

                    for (let i = 0; i < top.length; i++) {
                        const r = top[i];
                        let contact = null;
                        if (r.uid) {
                            try { contact = await getContactCached(r.uid); } catch (e) { contact = null; }
                        }
                        if (!contact && r.number) {
                            const uid = `${r.number}@c.us`;
                            try { contact = await getContactCached(uid); } catch (e) { contact = null; }
                        }
                        const mentionId = contact && contact.id && contact.id._serialized ? contact.id._serialized : (r.uid ? r.uid : (r.number ? `${r.number}@c.us` : null));
                        const display = mentionId ? `@${mentionId.split('@')[0]}` : (r.number || 'unknown');
                        const formattedBal = `${formatNumber(Number(r.balance || 0))} Coin`;

                        if (i === 0) lines.push(`🥇 *1. ${display}*\n   💰 Saldo: ${formattedBal}`);
                        else if (i === 1) lines.push(`🥈 *2. ${display}*\n   💰 Saldo: ${formattedBal}`);
                        else if (i === 2) lines.push(`🥉 *3. ${display}*\n   💰 Saldo: ${formattedBal}`);
                        else lines.push(`▪️ *${i + 1}. ${display}*\n   💰 Saldo: ${formattedBal}`);

                        if (mentionId) mentions.push(mentionId);
                    }

                    const message = lines.join('\n');
                    const mentionIds = mentions.filter(Boolean);
                    if (mentionIds.length) replyQueue(msg, message, { mentions: mentionIds }, 'low'); else replyQueue(msg, message, undefined, 'low');
                } catch (e) {
                    console.error('Error generating top list:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat membuat leaderboard.', undefined, 'high');
                }
                return;
            }

            // .cekbal @user
            if (lower.startsWith('.cekbal')) {
                const targetObj = await getMentionedTarget(msg, body);
                if (!targetObj || (!targetObj.number && !targetObj.uid)) {
                    replyQueue(msg, 'Tandai pengguna yang ingin dicek contohnya: .cekbal @pengguna', undefined, 'high');
                    return;
                }
                const reg = findRegistrationForTarget(targetObj, regs);
                const display = (reg && reg.number) || (targetObj.number || targetObj.uid);
                if (!reg) {
                    replyQueue(msg, '🔐 Anda belum teregistrasi!', undefined, 'high');
                    return;
                }
                const bal = Number(reg.balance || 0);
                // Try to mention the user if we can resolve a serialized id
                const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
                if (maybeId) {
                    replyQueue(msg, `Balance @${maybeId.split('@')[0]}: ${bal}`, { mentions: [maybeId] }, 'high');
                } else {
                    replyQueue(msg, `Balance ${display}: ${bal}`, undefined, 'high');
                }
                return;
            }

            // .addbal @user 5000 — support also: .addbal 628123456789 1000
            if (lower.startsWith('.addbal') || lower.startsWith('.removebal')) {
                // try mentioned target first, then fall back to plain-number token
                let targetObj = await getMentionedTarget(msg, body);
                // parse tokens
                const parts = body.split(/\s+/);
                // if no mention/uid found, try to parse the second token as a phone number
                if ((!targetObj || (!targetObj.number && !targetObj.uid)) && parts.length >= 2) {
                    const maybeToken = parts[1] || '';
                    const digits = String(maybeToken).replace(/[^0-9]/g, '');
                    if (digits) {
                        targetObj = { number: digits };
                        try {
                            const tryUid = `${digits}@c.us`;
                            const contact = await getContactCached(tryUid);
                            if (contact && contact.id && contact.id._serialized) targetObj.uid = contact.id._serialized;
                        } catch (e) { /* ignore if cannot resolve */ }
                    }
                }

                const maybeAmount = (parts.length >= 3 ? parts[parts.length - 1] : '');
                const amount = parseAmountToken(maybeAmount || '0');

                // If missing target or missing amount, show usage (specialized for .addbal/.removebal)
                if (!targetObj || (!targetObj.number && !targetObj.uid) || !maybeAmount) {
                    if (lower.startsWith('.addbal')) {
                        replyQueue(msg, '⚠️ Gunakan format: *.addbal [nomor atau @mention] [nominal_coin]*\nContoh: .addbal 628123456789 1000 atau .addbal @628123456789 1000', undefined, 'high');
                    } else {
                        replyQueue(msg, '⚠️ Gunakan format: *.removebal [nomor atau @mention] [nominal_coin]*\nContoh: .removebal 628123456789 1000 atau .removebal @628123456789 1000', undefined, 'high');
                    }
                    return;
                }

                if (!amount || amount <= 0) {
                    if (lower.startsWith('.addbal')) {
                        replyQueue(msg, '⚠️ Gunakan format: *.addbal [nomor atau @mention] [nominal_coin]*\nContoh: .addbal 628123456789 1000 atau .addbal @628123456789 1000', undefined, 'high');
                    } else {
                        replyQueue(msg, '⚠️ Gunakan format: *.removebal [nomor atau @mention] [nominal_coin]*\nContoh: .removebal 628123456789 1000 atau .removebal @628123456789 1000', undefined, 'high');
                    }
                    return;
                }

                // Prefer atomic helpers for admin balance operations where available
                if (lower.startsWith('.addbal')) {
                    await adminAddBalance(targetObj, amount, msg);
                    return;
                }
                if (lower.startsWith('.removebal')) {
                    await adminRemoveBalance(targetObj, amount, msg);
                    return;
                }

                // Re-resolve registration inside lock to avoid race
                if (lower.startsWith('.addbal')) {
                    await withRegistrationsLock(async (regsNow) => {
                        const reg = findRegistrationForTarget(targetObj, regsNow);
                        const display = (reg && reg.number) || (targetObj.number || targetObj.uid);
                        if (!reg) {
                            replyQueue(msg, `Pengguna ${display} belum teregistrasi.`, undefined, 'high');
                            return;
                        }
                        reg.balance = Number(reg.balance || 0) + amount;
                        const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
                        const addedFmt = formatNumber(amount);
                        const currentFmt = formatNumber(reg.balance);
                        if (maybeId) {
                            replyQueue(msg, `✅ Berhasil menambahkan ${addedFmt} Coin ke @${maybeId.split('@')[0]}.\n💰 Coin saat ini: *${currentFmt} Coin*`, { mentions: [maybeId] }, 'high');
                        } else {
                            replyQueue(msg, `✅ Berhasil menambahkan ${addedFmt} Coin ke ${display}.\n💰 Coin saat ini: *${currentFmt} Coin*`, undefined, 'high');
                        }
                    });
                    return;
                }

                // removebal
                if (lower.startsWith('.removebal')) {
                    await withRegistrationsLock(async (regsNow) => {
                        const reg = findRegistrationForTarget(targetObj, regsNow);
                        const display = (reg && reg.number) || (targetObj.number || targetObj.uid);
                        if (!reg) {
                            replyQueue(msg, `Pengguna ${display} belum teregistrasi.`, undefined, 'high');
                            return;
                        }
                        const current = Number(reg.balance || 0);
                        if (current < amount) {
                            const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
                            if (maybeId) {
                                replyQueue(msg, `Saldo @${maybeId.split('@')[0]} tidak cukup (saat ini ${current}).`, { mentions: [maybeId] }, 'high');
                            } else {
                                replyQueue(msg, `Saldo ${display} tidak cukup (saat ini ${current}).`, undefined, 'high');
                            }
                            return;
                        }
                        reg.balance = current - amount;
                        const maybeId = ensureSerializedId((reg && reg.uid) || reg.number || targetObj.uid || targetObj.number);
                        const removedFmt = formatNumber(amount);
                        const currentFmt = formatNumber(reg.balance);
                        if (maybeId) {
                            replyQueue(msg, `✅ Berhasil mengurangi ${removedFmt} Coin dari @${maybeId.split('@')[0]}.\n💰 Coin saat ini: *${currentFmt} Coin*`, { mentions: [maybeId] }, 'high');
                        } else {
                            replyQueue(msg, `✅ Berhasil mengurangi ${removedFmt} Coin dari ${display}.\n💰 Coin saat ini: *${currentFmt} Coin*`, undefined, 'high');
                        }
                    });
                    return;
                }
            }
        }

        // .historytf command disabled to avoid I/O latency and history storage
        if (lower.startsWith('.historytf')) {
            const isAdmin = await isSenderAdmin(chat, senderId);
            if (!isAdmin) {
                replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high');
                return;
            }
            replyQueue(msg, 'Perintah .historytf telah dinonaktifkan. Riwayat TF telah dihapus dan tidak akan disimpan lagi.', undefined, 'high');
            return;
        }

        // .totalcoin - show totals across users and bank (admin-only)
        if (lower === '.totalcoin') {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const regsAll = loadRegistrations() || [];
                const totalUsers = regsAll.reduce((acc, r) => acc + (Number(r.balance || 0)), 0);
                const bank = loadBank();
                const bankTotal = Number(bank.total || 0);
                const totalSystem = Number(totalUsers) + bankTotal;

                const lastUpdate = bank.updatedAt ? formatUTC7(new Date(bank.updatedAt)) : formatUTC7(new Date());

                const nowCalc = formatUTC7(new Date());

                const lines = [];
                lines.push('💰 *Total Coin Sistem*\n');
                lines.push(`👥 Total Coin User: *${formatNumber(totalUsers)}*`);
                lines.push(`🏦 Total Coin Bank: *${formatNumber(bankTotal)}*`);
                lines.push(`🌐 Total Seluruh Sistem: *${formatNumber(totalSystem)}*\n`);
                lines.push(`🕒 Terakhir update bank: ${lastUpdate}`);
                lines.push(`📊 Waktu perhitungan: ${nowCalc}`);

                replyQueue(msg, lines.join('\n'), undefined, 'low');
            } catch (e) {
                console.error('Error generating .totalcoin:', e);
                replyQueue(msg, 'Terjadi kesalahan saat menghitung total coin.', undefined, 'high');
            }
            return;
        }

        // Admin-only: manual clear (plong) and bank management commands
        if (lower === '.plong') {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                await replyQueue(msg, '🌳 Memulai clear chat pada semua grup (proses akan berjalan)...', undefined, 'high');
                try {
                    await clearAllGroupChatsForBot();
                    await replyQueue(msg, '🌳 Clear chat pada bot telah berhasil', undefined, 'high');
                } catch (e) {
                    console.error('Error running .plong:', e);
                    await replyQueue(msg, '❌ Gagal melakukan clear chat: ' + (e && e.message ? e.message : String(e)), undefined, 'high');
                }
            } catch (e) {
                console.error('Error handling .plong:', e);
                try { replyQueue(msg, 'Terjadi kesalahan saat menjalankan .plong', undefined, 'high'); } catch (e2) { /* ignore */ }
            }
            return;
        }

        if (lower === '.cekbank') {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }
                const bank = loadBank() || { total: 0, updatedAt: null };
                const total = Number(bank.total || 0);
                replyQueue(msg, `🏦 Total saldo bank saat ini: ${formatNumber(total)}`, undefined, 'high');
            } catch (e) {
                console.error('Error handling .cekbank:', e);
                replyQueue(msg, 'Terjadi kesalahan saat mengecek saldo bank.', undefined, 'high');
            }
            return;
        }

        if (lower.startsWith('.addbank')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const parts = body.split(/\s+/);
                if (parts.length < 2) { replyQueue(msg, 'Gunakan: .addbank 1000', undefined, 'high'); return; }
                const amt = parseAmountToken(parts[1]);
                if (!amt || amt <= 0) { replyQueue(msg, 'Nominal tidak valid. Contoh: .addbank 1000 atau .addbank 1.5k', undefined, 'high'); return; }

                const res = addToBank(amt);
                if (!res) { replyQueue(msg, 'Gagal menambahkan saldo ke bank.', undefined, 'high'); return; }
                const newTotal = Number(res.total || 0);
                replyQueue(msg, `✅ Berhasil menambahkan ${formatNumber(amt)} ke bank. Saldo sekarang: ${formatNumber(newTotal)}`, undefined, 'high');
            } catch (e) {
                console.error('Error handling .addbank:', e);
                replyQueue(msg, 'Terjadi kesalahan saat menambahkan saldo ke bank.', undefined, 'high');
            }
            return;
        }

        if (lower.startsWith('.removebank')) {
            try {
                const isAdminNow = await isSenderAdmin(chat, senderId);
                if (!isAdminNow) { replyQueue(msg, '🚫 Hanya admin yang bisa menjalankan perintah ini!', undefined, 'high'); return; }

                const parts = body.split(/\s+/);
                if (parts.length < 2) { replyQueue(msg, 'Gunakan: .removebalbank 1000', undefined, 'high'); return; }
                const amt = parseAmountToken(parts[1]);
                if (!amt || amt <= 0) { replyQueue(msg, 'Nominal tidak valid. Contoh: .removebalbank 1000 atau .removebalbank 1k', undefined, 'high'); return; }

                const bank = loadBank() || { total: 0 };
                const current = Number(bank.total || 0);
                if (amt > current) { replyQueue(msg, `❌ Gagal: nominal lebih besar dari saldo bank saat ini (${formatNumber(current)})`, undefined, 'high'); return; }

                const newTotal = current - amt;
                try {
                    saveBank({ total: newTotal });
                    replyQueue(msg, `✅ Berhasil mengurangi ${formatNumber(amt)} dari bank. Saldo sekarang: ${formatNumber(newTotal)}`, undefined, 'high');
                } catch (e) {
                    console.error('Failed to save new bank total:', e);
                    replyQueue(msg, '❌ Gagal menyimpan perubahan saldo bank.', undefined, 'high');
                }
            } catch (e) {
                console.error('Error handling .removebank:', e);
                replyQueue(msg, 'Terjadi kesalahan saat mengurangi saldo bank.', undefined, 'high');
            }
            return;
        }
        // Public commands that don't require registration (e.g. .ping)
        if (body.toLowerCase() === '.ping') {
            try {
                // Estimate latency more robustly by checking multiple possible timestamp fields
                let latency = 0;
                try {
                    const candidates = [
                        msg && msg.messageTimestamp,
                        msg && msg.message && (msg.message.timestamp || msg.messageTimestamp),
                        msg && msg.timestamp,
                        msg && msg.t
                    ];
                    let tsSec = null;
                    for (const c of candidates) {
                        if (typeof c === 'number' && !isNaN(c)) { tsSec = c; break; }
                        if (typeof c === 'string' && c.trim() !== '' && !isNaN(Number(c))) { tsSec = Number(c); break; }
                    }
                    if (!tsSec) tsSec = Math.floor(Date.now() / 1000);
                    const recvMs = Number(tsSec) * 1000;
                    const rtt = Date.now() - recvMs;
                    latency = (rtt >= 0 && rtt < 1000 * 60 * 60) ? rtt : 0;
                } catch (e) { latency = 0; }
                await immediateReply(msg, `Pong! Latency: ${latency} ms`, undefined);
            } catch (e) {
                console.error('Error handling .ping:', e);
                await immediateReply(msg, 'Pong!', undefined);
            }
            return;
        }

        // General dot-commands require sender to be registered
        // Also allow single-symbol-prefixed 'gass' (e.g. !gass, #gass) to enter
        const startsSingleSymbolGass = (function (t) { try { return !!(t && t.trim().match(/^([^A-Za-z0-9\s])gass(?:\b|\s|$)/i)); } catch (e) { return false; } })(body);
        if (body.startsWith('.') || startsSingleSymbolGass) {
            const registered = regs.find(r => r.number === senderNumber);
            if (!registered) {
                replyQueue(msg, '🔐 Anda belum teregistrasi!', undefined, 'high');
                return;
            }

            // .qr - send QRIS image to registered users
            if (body.toLowerCase() === '.qr') {
                try {
                    // Use preloaded media if available to avoid disk I/O per-request
                    if (preloadedMedia.qris) {
                        await sendQueue(chat.id._serialized, preloadedMedia.qris, { caption: '🖼️ QRIS GEMSPIN\n(Setelah TP jangan lupa SS!)' });
                        return;
                    }
                    // Fallback: try async file read and build MessageMedia
                    const imgPath = path.join(__dirname, 'qris.png');
                    const data = await fs.promises.readFile(imgPath).catch(() => null);
                    if (!data) {
                        replyQueue(msg, 'Gagal: file qris.png tidak ditemukan.', undefined, 'high');
                        return;
                    }
                    const base64 = data.toString('base64');
                    const media = new MessageMedia('image/png', base64, 'qris.png');
                    await sendQueue(chat.id._serialized, media, { caption: '🖼️ QRIS GEMSPIN\n(Setelah TP jangan lupa SS!)' });
                } catch (e) {
                    console.error('Error sending QRIS image:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat mengirim QRIS.', undefined, 'high');
                }
                return;
            }

            // .listqris - simple plaintext listing for QRIS (registered users only)
            if (body.toLowerCase() === '.listqris') {
                try {
                    const lines = [];
                    lines.push('📋 *D A F T A R   Q R I S* 📋\n');
                    lines.push('1. *GEMSPIN GAMING*\n');
                    lines.push('Total QRIS: 1');
                    replyQueue(msg, lines.join('\n'), undefined, 'high');
                } catch (e) {
                    console.error('Error in .listqris:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat menampilkan daftar QRIS.', undefined, 'high');
                }
                return;
            }

            // .gass - Putar Roulette (registered users only)
            // Accepts one single-symbol prefix before 'gass' (e.g. .gass, !gass, #gass, $gass)
            const gassMatch = (function (txt) {
                try {
                    if (!txt) return null;
                    // trimmed original (preserve case-insensitive checking)
                    const t = txt.trim();
                    // match a single non-alphanumeric symbol followed by 'gass' and word boundary
                    const m = t.match(/^([^A-Za-z0-9\s])gass(?:\b|\s|$)/i);
                    if (m) return { prefix: m[1], matched: m[0] };
                    // Also allow plain 'gass' without symbol
                    const m2 = t.match(/^gass(?:\b|\s|$)/i);
                    if (m2) return { prefix: '.', matched: m2[0] };
                    return null;
                } catch (e) { return null; }
            })(body);
            if (gassMatch) {
                try {
                    // mark inflight for this spin so takeover can detect in-progress game actions
                    const gmid = (msg && msg.id && msg.id._serialized) ? msg.id._serialized : (`gass:${msg.from}:${Date.now()}`);
                    const gkey = `inflight:cmd:gass:${gmid}`;
                    try {
                        await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'received' }, 30000);
                    } catch (e) { /* ignore */ }
                    try {
                        await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'processing' }, 30000);
                    } catch (e) { /* ignore */ }
                    try {
                        // update message-level inflight as well
                        if (inflightKey) await DB.setInflight(inflightKey, { instance: INSTANCE_ID, chatId: (chat && chat.id && chat.id._serialized) || null, sender: senderNumber, body, ts: Date.now(), stage: 'processing' }, 30 * 1000);
                    } catch (e) { /* ignore */ }
                    // Ensure idle-clear timer is reset when a user issues a gass command
                    // so the idle-clear doesn't stop working after a spin.
                    try { resetIdleClearTimer(); } catch (e) { /* ignore */ }
                    // Use crypto.randomInt for fair RNG (0..36 inclusive)
                    //const number = crypto.randomInt(0, 37);
                    // GLOBAL anti-duplicate spin using Redis (works cross-process)
                    // Fallbacks included: crypto.randomInt and in-process Map if Redis unavailable

                    let number = null;
                    const MAX_ATTEMPTS = 2;
                    const CLAIM_TTL_MS = 2000; // how long a claimed number is "reserved" (2s)

                    // helper to generate a candidate
                    const genCand = () => crypto.randomInt(0, 37);

                    try {
                        // If redis available, try atomic claim there (recommended for multi-instance)
                        if (typeof redisClient !== 'undefined' && redisClient && redisClient.isReady) {
                            for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
                                const cand = genCand();
                                const key = `spin:claim:${cand}`;
                                // Node-redis v4 syntax: set(key, value, { NX: true, PX: CLAIM_TTL_MS })
                                // value can be a small token (timestamp + pid) but not used after
                                const setRes = await redisClient.set(key, `${Date.now()}`, { NX: true, PX: CLAIM_TTL_MS });
                                if (setRes === 'OK') { number = cand; break; }
                                // otherwise, someone else has it; try again
                            }
                            // If none claimed after attempts, fallback to pure crypto.randomInt (allow duplicates rarely)
                            if (number === null) number = genCand();
                        } else {
                            // Redis not available -> fall back to in-process Map solution
                            if (!global.__spinClaims) global.__spinClaims = new Map(); // number -> expiryTimestamp
                            const now = Date.now();
                            // clean up expired entries
                            for (const [k, exp] of global.__spinClaims.entries()) {
                                if (exp <= now) global.__spinClaims.delete(k);
                            }

                            for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
                                const cand = genCand();
                                if (!global.__spinClaims.has(cand)) {
                                    // claim for CLAIM_TTL_MS
                                    global.__spinClaims.set(cand, now + CLAIM_TTL_MS);
                                    number = cand;
                                    break;
                                }
                            }
                            if (number === null) number = genCand();
                        }
                    } catch (e) {
                        // conservative fallback if something goes wrong: try pure crypto + defensive fallback
                        try {
                            number = crypto.randomInt(0, 37);
                        } catch (ee) {
                            const buf = crypto.randomBytes(8);
                            const v = buf.readUInt32BE(0) ^ buf.readUInt32BE(4);
                            number = Math.abs(v) % 37;
                        }
                    }


                    // Determine if the user is currently in a PvP room in this group
                    let inRoom = null;
                    try {
                        // Use Redis-backed rooms list instead of filesystem scan
                        const rooms = await listPvpRooms();
                        for (const room of rooms || []) {
                            if (!room) continue;
                            if (room.groupId !== (chat && chat.id && chat.id._serialized)) continue;
                            if (!Array.isArray(room.participants)) continue;
                            const participants = room.participants.map(p => p.number);
                            if (!participants.includes(senderNumber)) continue;
                            inRoom = room;
                            break;
                        }
                    } catch (e) {
                        inRoom = null;
                    }

                    const mentionId = ensureSerializedId(registered.uid || senderId || registered.number);
                    const mentionDisplay = mentionId ? `@${mentionId.split('@')[0]}` : `@${senderNumber}`;

                    // Compose header and result depending on whether user is in a room
                    if (!inRoom) {
                        const text = `🎡 Roulette Spinning! 🎡\n\n${mentionDisplay} spin the wheel and got ${number}`;
                        if (mentionId) replyQueue(msg, text, { mentions: [mentionId] }, 'high'); else replyQueue(msg, text, undefined, 'high');
                    } else {
                        const roomLabel = inRoom.code || '';
                        const text = `🎡 Roulette Spinning! 🎡(Room: *${roomLabel}*)\n\n${mentionDisplay} spin the wheel and got ${number}`;
                        if (mentionId) replyQueue(msg, text, { mentions: [mentionId] }, 'high'); else replyQueue(msg, text, undefined, 'high');
                    }

                    // history logging disabled (no JSON history storage)
                    try {
                        // Use Redis-backed rooms list instead of filesystem scan
                        const rooms = await listPvpRooms();
                        for (const room of rooms || []) {
                            if (!room) continue;
                            if (room.groupId !== (chat && chat.id && chat.id._serialized)) continue;
                            if (room.status !== 'active') continue;
                            if (!Array.isArray(room.participants)) continue;
                            const participants = room.participants.map(p => p.number);
                            if (!participants.includes(senderNumber)) continue;

                            const round = room.currentRound || 1;
                            room.results = room.results || {};
                            room.results[round] = room.results[round] || {};

                            const rem = sumDigits(number);
                            if (room.results[round][senderNumber] !== undefined) {
                                const mentionId = ensureSerializedId(registered.uid || senderId || registered.number);
                                const warn = mentionId ? `@${mentionId.split('@')[0]} kamu sudah memutar untuk ronde ${round}, hanya spin pertama yang dihitung.` : `Kamu sudah memutar untuk ronde ${round}, hanya spin pertama yang dihitung.`;
                                if (mentionId) sendQueue(chat.id._serialized, warn, { mentions: [mentionId] }); else sendQueue(chat.id._serialized, warn);
                                continue;
                            }

                            room.results[round][senderNumber] = { raw: number, rem };
                            await savePvpRoom(room);
                            try { await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'saved' }, 30000); } catch (e) { /* ignore */ }

                            // if both players spun, evaluate round
                            const have = participants.filter(n => room.results[round] && room.results[round][n] !== undefined);
                            if (have.length === 2) {
                                const p0 = room.participants[0];
                                const p1 = room.participants[1];
                                const r0 = room.results[round][p0.number];
                                const r1 = room.results[round][p1.number];
                                const m0 = ensureSerializedId(p0.uid || p0.number);
                                const m1 = ensureSerializedId(p1.uid || p1.number);
                                const mentions = [];
                                if (m0) mentions.push(m0);
                                if (m1) mentions.push(m1);

                                // Build round result message
                                const lines = [];
                                lines.push(`🎮 *PVP REME RONDE ${round} HASIL* 🎮\n`);
                                lines.push(`${m0 ? `@${m0.split('@')[0]}` : p0.number} roll: ${r0.raw} (REME: ${r0.rem})`);
                                lines.push(`${m1 ? `@${m1.split('@')[0]}` : p1.number} roll: ${r1.raw} (REME: ${r1.rem})\n`);

                                // Determine round winner
                                room.wins = room.wins || {};
                                const rem0 = Number(r0.rem || 0);
                                const rem1 = Number(r1.rem || 0);
                                if (rem0 === rem1) {
                                    // Round draw: clear this round results and ask both players to gass again
                                    delete room.results[round];
                                    await savePvpRoom(room);
                                    try { await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'saved' }, 30000); } catch (e) { /* ignore */ }

                                    const tieLines = [];
                                    tieLines.push(`🎮 *PVP REME RONDE ${round} HASIL* 🎮\n`);
                                    tieLines.push(`${m0 ? `@${m0.split('@')[0]}` : p0.number} roll: ${r0.raw} (REME: ${r0.rem})`);
                                    tieLines.push(`${m1 ? `@${m1.split('@')[0]}` : p1.number} roll: ${r1.raw} (REME: ${r1.rem})\n`);
                                    tieLines.push(`Seri! Keduanya mendapatkan ${r0.raw} (REME: ${r0.rem})`);
                                    tieLines.push(`Kedua pemain silahkan ketik *.gass* untuk melanjutkan ke ronde berikutnya!🙄`);
                                    tieLines.push('⏱️ Batas waktu: 3 menit');

                                    const tieMsg = tieLines.join('\n');
                                    if (mentions.length) sendQueue(chat.id._serialized, tieMsg, { mentions }); else sendQueue(chat.id._serialized, tieMsg);

                                    // restart active timer for the same round
                                    try { startActiveTimer(room.code, chat.id._serialized); } catch (e) { /* ignore */ }
                                    continue;
                                }

                                let roundWinnerNumber;
                                if (rem0 === 0 && rem1 !== 0) {
                                    roundWinnerNumber = p0.number;
                                } else if (rem1 === 0 && rem0 !== 0) {
                                    roundWinnerNumber = p1.number;
                                } else {
                                    roundWinnerNumber = (rem0 > rem1) ? p0.number : p1.number;
                                }
                                const roundLoserNumber = (roundWinnerNumber === p0.number) ? p1.number : p0.number;
                                room.wins[roundWinnerNumber] = (room.wins[roundWinnerNumber] || 0) + 1;
                                await savePvpRoom(room);
                                try { await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'saved' }, 30000); } catch (e) { /* ignore */ }

                                // Prepare winner summary line
                                const winnerIsP0 = (roundWinnerNumber === p0.number);
                                const winnerRaw = winnerIsP0 ? r0.raw : r1.raw;
                                const winnerRem = winnerIsP0 ? r0.rem : r1.rem;
                                const loserRaw = winnerIsP0 ? r1.raw : r0.raw;
                                const loserRem = winnerIsP0 ? r1.rem : r0.rem;
                                const winnerMention = winnerIsP0 ? (m0 ? `@${m0.split('@')[0]}` : p0.number) : (m1 ? `@${m1.split('@')[0]}` : p1.number);
                                lines.push(`${winnerMention} menang dengan ${winnerRaw} (REME: ${winnerRem}) vs ${loserRaw} (REME: ${loserRem})\n`);

                                // Score (player1 - player2)
                                const wins0 = room.wins[p0.number] || 0;
                                const wins1 = room.wins[p1.number] || 0;
                                lines.push(`🏅 Score: ${wins0}-${wins1}`);

                                // Send round result message
                                const roundMsg = lines.join('\n');
                                if (mentions.length) sendQueue(chat.id._serialized, roundMsg, { mentions }); else sendQueue(chat.id._serialized, roundMsg);

                                // If there are more rounds configured, advance and prompt next round
                                const maxRounds = room.maxRounds || 1;
                                if ((room.currentRound || 1) < maxRounds) {
                                    room.currentRound = (room.currentRound || 1) + 1;
                                    await savePvpRoom(room);
                                    const next = room.currentRound;
                                    const prompt = `\n🎲 *RONDE ${next}* 🎲\nKedua pemain silahkan ketik *.gass* untuk melanjutkan!\n⏱️ Batas waktu: 3 menit`;
                                    if (mentions.length) sendQueue(chat.id._serialized, prompt, { mentions }); else sendQueue(chat.id._serialized, prompt);
                                    // restart active timer for the new round
                                    try { startActiveTimer(room.code, chat.id._serialized); } catch (e) { /* ignore */ }
                                    continue;
                                }

                                // After configured rounds complete, decide by round wins
                                if (wins0 === wins1) {
                                    // tie in total rounds -> add final tiebreaker round and show tiebreaker message
                                    room.maxRounds = (room.maxRounds || 1) + 1;
                                    room.currentRound = (room.currentRound || 1) + 1;
                                    await savePvpRoom(room);

                                    const tieBreakerLines = [];
                                    const tbRound = round;
                                    const nextRound = room.currentRound;
                                    tieBreakerLines.push(`🎮 *PVP REME TIEBREAKER ROUND ${tbRound} HASIL* 🎮\n`);
                                    tieBreakerLines.push(`Seri! Kedua pemain memiliki score seimbang\n`);
                                    tieBreakerLines.push(`🏅 Score: ${wins0}-${wins1}`);
                                    tieBreakerLines.push(`\n🎲 *TIEBREAKER ROUND ${nextRound}* 🎲`);
                                    tieBreakerLines.push(`Kedua pemain silahkan ketik *.gass* untuk melanjutkan!`);
                                    tieBreakerLines.push('⏱️ Batas waktu: 3 menit');

                                    const tbMsg = tieBreakerLines.join('\n');
                                    if (mentions.length) sendQueue(chat.id._serialized, tbMsg, { mentions }); else sendQueue(chat.id._serialized, tbMsg);

                                    // start active timer for the tie-breaker
                                    try { startActiveTimer(room.code, chat.id._serialized); } catch (e) { /* ignore */ }
                                    continue;
                                }

                                const winnerNumber = (wins0 > wins1) ? p0.number : p1.number;
                                const loserNumber = (winnerNumber === p0.number) ? p1.number : p0.number;
                                let wreg = null;
                                let lreg = null;
                                let escrow = Number(room.escrow || 0);
                                let award = 0;
                                let fee = 0;
                                try {
                                    // Prefer atomic award via Redis Lua helper to avoid full-table lock
                                    if (DB && typeof DB.atomicAddToUser === 'function') {
                                        try {
                                            fee = Math.floor(escrow * 0.035);
                                            award = escrow - fee;
                                            try {
                                                await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'awarding' }, 30000);
                                            } catch (e) { /* ignore */ }
                                            const newBal = await DB.atomicAddToUser(winnerNumber, award);
                                            try {
                                                if (newBal !== null) await DB.setInflight(gkey, { instance: INSTANCE_ID, cmd: 'gass', id: gmid, ts: Date.now(), stage: 'awarded' }, 30000);
                                            } catch (e) { /* ignore */ }
                                            if (newBal !== null) {
                                                invalidateRegsCache();
                                                const regsNow = loadRegistrations();
                                                wreg = regsNow.find(r => r.number === winnerNumber);
                                                lreg = regsNow.find(r => r.number === loserNumber);
                                            } else {
                                                // atomic helper failed, fallback to locked update
                                                await withRegistrationsLock(async (regsNow) => {
                                                    wreg = regsNow.find(r => r.number === winnerNumber);
                                                    lreg = regsNow.find(r => r.number === loserNumber);
                                                    if (wreg && lreg) {
                                                        fee = Math.floor(escrow * 0.035);
                                                        award = escrow - fee;
                                                        wreg.balance = Number(wreg.balance || 0) + award;
                                                    }
                                                });
                                            }
                                        } catch (e) {
                                            console.error('atomicAddToUser failed, falling back to locked update:', e);
                                            await withRegistrationsLock(async (regsNow) => {
                                                wreg = regsNow.find(r => r.number === winnerNumber);
                                                lreg = regsNow.find(r => r.number === loserNumber);
                                                if (wreg && lreg) {
                                                    fee = Math.floor(escrow * 0.035);
                                                    award = escrow - fee;
                                                    wreg.balance = Number(wreg.balance || 0) + award;
                                                }
                                            });
                                        }
                                    } else {
                                        await withRegistrationsLock(async (regsNow) => {
                                            wreg = regsNow.find(r => r.number === winnerNumber);
                                            lreg = regsNow.find(r => r.number === loserNumber);
                                            if (wreg && lreg) {
                                                fee = Math.floor(escrow * 0.035);
                                                award = escrow - fee;
                                                wreg.balance = Number(wreg.balance || 0) + award;
                                            }
                                        });
                                    }
                                    if (wreg && lreg) {
                                        // store fee in bank
                                        try { addToBank(fee); } catch (e) { console.error('Gagal menyimpan fee ke bank:', e); }

                                        const wm = ensureSerializedId(wreg.uid || wreg.number);
                                        const lm = ensureSerializedId(lreg.uid || lreg.number);

                                        // Build final game over message
                                        const lastRound = round;
                                        const finalLines = [];
                                        finalLines.push('🎮 *PVP REME GAME OVER* 🎮\n');
                                        finalLines.push('Mode: REME');
                                        // show last round result: winner vs loser raw/rem
                                        const lastWinner = (winnerNumber === p0.number) ? r0 : r1;
                                        const lastLoser = (winnerNumber === p0.number) ? r1 : r0;
                                        const winnerMentionFinal = wm ? `@${wm.split('@')[0]}` : wreg.number;
                                        const loserMentionFinal = lm ? `@${lm.split('@')[0]}` : lreg.number;
                                        finalLines.push(`Round ${lastRound}: ${winnerMentionFinal} menang dengan ${lastWinner.raw} (REME: ${lastWinner.rem}) vs ${lastLoser.raw} (REME: ${lastLoser.rem})\n`);
                                        finalLines.push(`🏆 Pemenang: ${winnerMentionFinal}`);
                                        finalLines.push(`😔 Kalah: ${loserMentionFinal}`);
                                        finalLines.push(`🏅 Skor Akhir: ${wins0}-${wins1}`);
                                        finalLines.push(`💰 Hadiah: ${escrow} (sudah dipotong fee 3.5%)\n`);
                                        finalLines.push('Trima kasih telah bermain!');

                                        const finalMsg = finalLines.join('\n');
                                        const finalMentions = [];
                                        if (wm) finalMentions.push(wm);
                                        if (lm) finalMentions.push(lm);
                                        if (finalMentions.length) sendQueue(chat.id._serialized, finalMsg, { mentions: finalMentions }); else sendQueue(chat.id._serialized, finalMsg);
                                    } else {
                                        sendQueue(chat.id._serialized, 'Pemenang ditemukan, tetapi gagal mengupdate saldo (registrasi tidak ditemukan).');
                                    }
                                } catch (e) {
                                    console.error('PvP finalize error:', e);
                                    sendQueue(chat.id._serialized, 'Terjadi kesalahan saat menyelesaikan pvp.');
                                }

                                await deletePvpRoomFile(room.code);
                                if (pvpRoomTimeouts.has(room.code)) { clearTimeout(pvpRoomTimeouts.get(room.code)); pvpRoomTimeouts.delete(room.code); }
                                // clear active timer if exists
                                try { clearActiveTimer(room.code); } catch (e) { /* ignore */ }
                            }
                        }
                    } catch (e) {
                        console.error('PvP processing error after .gass:', e);
                    }
                    try { await DB.clearInflight(gkey); } catch (e) { /* ignore */ }
                } catch (e) {
                    console.error('Error during .gass:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat memutar roulette.', undefined, 'high');
                }
                return;
            }

            // Prioritize .bal command: show balance to the requesting registered user
            if (lower.startsWith('.bal')) {
                try {
                    // Check if there's a mentioned user to inspect
                    const targetObj = await getMentionedTarget(msg, body);
                    if (targetObj && (targetObj.number || targetObj.uid)) {
                        const targetReg = findRegistrationForTarget(targetObj, regs);
                        if (!targetReg) {
                            const display = (targetObj.number || targetObj.uid);
                            replyQueue(msg, `Pengguna ${display} belum teregistrasi.`, undefined, 'high');
                            return;
                        }
                        const bal = Number(targetReg.balance || 0);
                        const maybeId = ensureSerializedId(targetReg.uid || targetReg.number || targetObj.uid || targetObj.number);
                        const formatted = `${formatNumber(bal)} Coin`;
                        if (maybeId) {
                            replyQueue(msg, `💰 Coin @${maybeId.split('@')[0]} saat ini: ${formatted}`, { mentions: [maybeId] }, 'high');
                        } else {
                            replyQueue(msg, `💰 Coin ${targetReg.number} saat ini: ${formatted}`, undefined, 'high');
                        }
                        return;
                    }

                    // No mention — show caller's balance
                    const reg = regs.find(r => r.number === senderNumber);
                    const bal = Number((reg && reg.balance) || 0);
                    const mentionMe = ensureSerializedId((reg && reg.uid) || reg.number || senderNumber);
                    const formattedMe = `${formatNumber(bal)} Coin`;
                    if (mentionMe) {
                        replyQueue(msg, `💰 Coin @${mentionMe.split('@')[0]} saat ini: ${formattedMe}`, { mentions: [mentionMe] }, 'high');
                    } else {
                        replyQueue(msg, `💰 Coin ${senderNumber} saat ini: ${formattedMe}`, undefined, 'high');
                    }
                } catch (e) {
                    console.error('Error during .bal (priority):', e);
                    replyQueue(msg, 'Terjadi kesalahan saat mengecek saldo.', undefined, 'high');
                }
                return;
            }

            // .pvp - create room or join existing one (syntax: .pvp reme <code> [bet ronde])
            if (lower.startsWith('.pvp')) {
                try {
                    const parts = body.split(/\s+/);
                    // Must be at least: .pvp <mode> <code>
                    if (parts.length < 3) {
                        replyQueue(msg, '❌ Perintah tidak valid. Mode yang tersedia: reme\n\n*Penggunaan*: .pvp [mode] [kode_room] [bet] [ronde]', undefined, 'high');
                        return;
                    }
                    const mode = (parts[1] || '').toLowerCase();
                    const code = parts[2];
                    // Ensure helper variables are defined for create/join flows
                    const existingCreatedRoom = await findPvpRoomByCreator(registered.number);
                    const existingRoom = await loadPvpRoom(code);
                    // Parse optional create params: <bet> <ronde>
                    let totalbet = 0;
                    let ronde = '';
                    if (parts.length >= 5) {
                        // parts[3] => bet, parts[4] => ronde (e.g. '1r' or '2r')
                        totalbet = parseAmountToken(parts[3]);
                        ronde = (parts[4] || '').toString().toLowerCase();
                        if (totalbet <= 0) { replyQueue(msg, '❌ Perintah tidak valid. Bet harus berupa angka positif (boleh menggunakan suffix "k" mis. 1k = 1000).', undefined, 'high'); return; }
                        if (!['1r', '2r'].includes(ronde)) { replyQueue(msg, '❌ Perintah tidak valid. Ronde harus "1r" atau "2r".', undefined, 'high'); return; }
                    }
                    if (mode !== 'reme') {
                        replyQueue(msg, '❌ Perintah tidak valid. Mode yang tersedia: reme\n\n*Penggunaan*: .pvp [mode] [kode_room] [bet] [ronde]', undefined, 'high');
                        return;
                    }

                    // Join: .pvp reme <code>
                    if (parts.length === 3) {
                        const lockKey = `lock:pvp:${code}`;
                        const lockToken = crypto.randomBytes(16).toString('hex');
                        let lockAcquired = false;
                        try {
                            lockAcquired = await DB.acquireLock(lockKey, lockToken, 5000, 50, 100);
                            if (!lockAcquired) { replyQueue(msg, 'Sedang ada proses lain, silakan coba lagi sebentar.', undefined, 'high'); return; }
                            const room = await loadPvpRoom(code);
                            if (!room) { replyQueue(msg, '😮 Room tidak ditemukan: ' + code, undefined, 'high'); return; }
                            if (room.groupId !== (chat && chat.id && chat.id._serialized)) { replyQueue(msg, 'Room ini tidak tersedia untuk grup ini.', undefined, 'high'); return; }
                            if (!Array.isArray(room.participants)) room.participants = [];
                            // If user is already a participant in THIS room, inform and don't re-add or deduct
                            if (room.participants.some(p => p && p.number === registered.number)) {
                                replyQueue(msg, '✅ Kamu sudah berada di room ini. Menunggu lawan untuk bergabung.', undefined, 'high');
                                return;
                            }
                            if (room.participants.length >= 2) { replyQueue(msg, '🧏🏻 Room sudah penuh.', undefined, 'high'); return; }

                            // Prevent join if user already created or is participant in another room (other than this one)
                            const otherCreated = await findPvpRoomByCreator(registered.number);
                            if (otherCreated && otherCreated.code !== room.code) {
                                replyQueue(msg, `❌ Anda sudah membuat room ${otherCreated.code}. Tidak dapat join room lain sebelum room Anda selesai.`, undefined, 'high');
                                return;
                            }
                            const otherPart = await findPvpRoomByParticipant(registered.number);
                            if (otherPart && otherPart.code !== room.code) {
                                replyQueue(msg, `❌ Anda sedang berada di room ${otherPart.code}. Tidak dapat join room lain.`, undefined, 'high');
                                return;
                            }

                            // Check joiner's balance only if they are NOT the room creator.
                            // Creator's stake should have been reserved at room creation (room.escrow),
                            // so they may not have sufficient free balance remaining and should still be allowed.
                            const tb = Number(room.totalbet || 0);
                            if (registered.number !== room.creator && Number(registered.balance || 0) < tb) {
                                replyQueue(msg, '🥱 Saldo Anda tidak cukup untuk join room ini.', undefined, 'high');
                                return;
                            }

                            // Add participant and deduct stakes atomically while holding the lock
                            room.participants.push({ number: registered.number, uid: registered.uid || undefined });
                            // If creator hasn't reserved enough escrow, reserve now atomically.
                            const escrowNow = Number(room.escrow || 0);
                            if (escrowNow < tb) {
                                if (DB && typeof DB.atomicReserveBalance === 'function') {
                                    try { await DB.setInflight(inflightKey, { instance: INSTANCE_ID, chatId: (chat && chat.id && chat.id._serialized) || null, sender: senderNumber, body, ts: Date.now(), stage: 'reserving_room_refund' }, 30 * 1000); } catch (e) { /* ignore */ }
                                    const newBal = await DB.atomicReserveBalance(room.creator, tb);
                                    try { await DB.setInflight(inflightKey, { instance: INSTANCE_ID, chatId: (chat && chat.id && chat.id._serialized) || null, sender: senderNumber, body, ts: Date.now(), stage: 'reserved_room_refund' }, 30 * 1000); } catch (e) { /* ignore */ }
                                    if (newBal === null) { replyQueue(msg, 'Pembuat room tidak lagi memiliki saldo yang cukup.', undefined, 'high'); return; }
                                    invalidateRegsCache();
                                } else {
                                    // fallback to in-process modification
                                    const regsNow = loadRegistrations();
                                    const creatorReg = regsNow.find(r => r.number === room.creator);
                                    if (!creatorReg || Number(creatorReg.balance || 0) < tb) { replyQueue(msg, 'Pembuat room tidak lagi memiliki saldo yang cukup.', undefined, 'high'); return; }
                                    creatorReg.balance = Number(creatorReg.balance || 0) - tb;
                                    saveRegistrations(regsNow);
                                }
                            }

                            // Deduct joiner's stake atomically
                            if (DB && typeof DB.atomicReserveBalance === 'function') {
                                const newBalJoin = await DB.atomicReserveBalance(registered.number, tb);
                                if (newBalJoin === null) { replyQueue(msg, '🥱 Saldo Anda tidak cukup.', undefined, 'high'); return; }
                                invalidateRegsCache();
                            } else {
                                const regsNow = loadRegistrations();
                                const joinReg = regsNow.find(r => r.number === registered.number);
                                if (!joinReg || Number(joinReg.balance || 0) < tb) { replyQueue(msg, '🥱 Saldo Anda tidak cukup.', undefined, 'high'); return; }
                                joinReg.balance = Number(joinReg.balance || 0) - tb;
                                saveRegistrations(regsNow);
                            }

                            // Update room status and escrow
                            room.status = 'active';
                            room.startedAt = new Date().toISOString();
                            room.escrow = Number((escrowNow || 0) + tb);
                            room.currentRound = 1;
                            room.maxRounds = room.maxRounds || (room.ronde === '2r' ? 2 : 1);
                            await savePvpRoom(room);

                            const mCreator = ensureSerializedId(room.creatorUid || room.creator);
                            const mJoin = ensureSerializedId(registered.uid || registered.number);
                            const mentions = [];
                            if (mCreator) mentions.push(mCreator);
                            if (mJoin) mentions.push(mJoin);
                            // Build PvP start message per requested format
                            const roomCode = room.code;
                            const bet = tb;
                            const maxR = room.maxRounds || 1;
                            const p0 = room.participants[0];
                            const p1 = room.participants[1];
                            const m0 = ensureSerializedId(p0.uid || p0.number);
                            const m1 = ensureSerializedId(p1.uid || p1.number);
                            const startLines = [];
                            startLines.push('🎮 *PVP REME DIMULAI!* 🎮\n');
                            startLines.push(`Mode: REME`);
                            startLines.push(`Room: ${roomCode}`);
                            startLines.push(`Bet: ${bet}`);
                            startLines.push(`Ronde: 1 dari ${maxR}\n`);
                            startLines.push(`${m0 ? `👤 Player 1: @${m0.split('@')[0]}` : `👤 Player 1: ${p0.number}`}`);
                            startLines.push(`${m1 ? `👤 Player 2: @${m1.split('@')[0]}` : `👤 Player 2: ${p1.number}`}`);
                            startLines.push('\nKedua pemain silahkan ketik *.gass* untuk melanjutkan!');
                            startLines.push('\n⏱️ Batas waktu: 3 menit');
                            const startMsg = startLines.join('\n');
                            const startMentions = [];
                            if (m0) startMentions.push(m0);
                            if (m1) startMentions.push(m1);
                            if (startMentions.length) replyQueue(msg, startMsg, { mentions: startMentions }, 'high'); else replyQueue(msg, startMsg, undefined, 'high');
                            if (pvpRoomTimeouts.has(room.code)) { clearTimeout(pvpRoomTimeouts.get(room.code)); pvpRoomTimeouts.delete(room.code); }
                            // Start active 3-minute timer for players to .gass
                            try { startActiveTimer(room.code, chat.id._serialized); } catch (e) { /* ignore */ }
                            return;
                        } finally {
                            try { if (lockAcquired) await DB.releaseLock(lockKey, lockToken); } catch (e) { /* ignore */ }
                        }
                    }

                    // Create room: .pvp reme <code> <bet> <ronde>
                    if (parts.length >= 5) {
                        // Prevent creating if user already created a room
                        if (existingCreatedRoom) { replyQueue(msg, `❌ Anda sudah membuat room ${existingCreatedRoom.code}. Tidak dapat membuat lebih dari satu room.`, undefined, 'high'); return; }
                        // Prevent creating if user is already participant in another room
                        const otherPartCreate = await findPvpRoomByParticipant(registered.number);
                        if (otherPartCreate) { replyQueue(msg, `❌ Anda sedang berada di room ${otherPartCreate.code}. Tidak dapat membuat room lain sebelum room tersebut selesai.`, undefined, 'high'); return; }
                        // Enforce minimum bet 1000 (1k)
                        if (Number(totalbet || 0) < 1000) { replyQueue(msg, '❌ Bet minimal untuk membuat room adalah 1000 (1k).', undefined, 'high'); return; }
                        if (Number(registered.balance || 0) < totalbet) { replyQueue(msg, '😵 Saldo tidak cukup! Dibutuhkan minimal untuk bet yang dipilih', undefined, 'high'); return; }

                        const lockKey = `lock:pvp:${code}`;
                        const lockToken = crypto.randomBytes(16).toString('hex');
                        let lockAcquired = false;
                        try {
                            lockAcquired = await DB.acquireLock(lockKey, lockToken, 5000, 50, 100);
                            if (!lockAcquired) { replyQueue(msg, 'Sedang ada proses lain, silakan coba lagi sebentar.', undefined, 'high'); return; }
                            // Ensure room code is not already used
                            const preexisting = await loadPvpRoom(code);
                            if (preexisting) { replyQueue(msg, `❌ Room dengan kode ${code} sudah ada. Gunakan kode lain.`, undefined, 'high'); return; }

                            const room = {
                                code,
                                mode: 'reme',
                                groupId: (chat && chat.id && chat.id._serialized),
                                creator: registered.number,
                                creatorUid: registered.uid || undefined,
                                totalbet,
                                ronde,
                                participants: [{ number: registered.number, uid: registered.uid || undefined }],
                                createdAt: new Date().toISOString(),
                                status: 'waiting',
                                maxRounds: (ronde === '2r' ? 2 : 1),
                                currentRound: 0,
                                results: {},
                                escrow: 0
                            };
                            // Immediately reserve creator's stake (escrow) to prevent cheating
                            try {
                                // Reserve creator's stake atomically when possible
                                if (DB && typeof DB.atomicReserveBalance === 'function') {
                                    const newBal = await DB.atomicReserveBalance(registered.number, totalbet);
                                    if (newBal === null) {
                                        replyQueue(msg, '😵 Saldo tidak cukup! Dibutuhkan 1.000 untuk Bet di room PVP', undefined, 'high');
                                        return;
                                    }
                                    invalidateRegsCache();
                                    room.escrow = Number(totalbet);
                                } else {
                                    const regsNow = loadRegistrations();
                                    const creatorReg = regsNow.find(r => r.number === registered.number);
                                    if (!creatorReg) {
                                        replyQueue(msg, 'Kesalahan: registrasi tidak ditemukan.', undefined, 'high');
                                        return;
                                    }
                                    if (Number(creatorReg.balance || 0) < totalbet) {
                                        replyQueue(msg, '😵 Saldo tidak cukup! Dibutuhkan 1.000 untuk Bet di room PVP', undefined, 'high');
                                        return;
                                    }
                                    creatorReg.balance = Number(creatorReg.balance || 0) - totalbet;
                                    saveRegistrations(regsNow);
                                    room.escrow = Number(totalbet);
                                }
                            } catch (e) {
                                console.error('Gagal men-reserve saldo pembuat room:', e);
                                replyQueue(msg, 'Terjadi kesalahan saat menyiapkan room.', undefined, 'high');
                                return;
                            }

                            await savePvpRoom(room);

                            const to = setTimeout(async () => {
                                const r = await loadPvpRoom(code);
                                if (!r) return;
                                if (!Array.isArray(r.participants) || r.participants.length < 2) {
                                    // refund creator's escrow (if any)
                                    try {
                                        const escrowAmt = Number(r.escrow || 0);
                                        if (escrowAmt > 0) {
                                            if (DB && typeof DB.atomicReleaseBalance === 'function') {
                                                await DB.atomicReleaseBalance(r.creator, escrowAmt);
                                                invalidateRegsCache();
                                            } else {
                                                const regsNow = loadRegistrations();
                                                const creatorReg = regsNow.find(x => x.number === r.creator);
                                                if (creatorReg) {
                                                    creatorReg.balance = Number(creatorReg.balance || 0) + escrowAmt;
                                                    saveRegistrations(regsNow);
                                                }
                                            }
                                        }
                                    } catch (e) {
                                        console.error('Gagal refund creator saat room expired:', e);
                                    }

                                    await deletePvpRoomFile(code);
                                    const creatorMention = ensureSerializedId(r.creatorUid || r.creator);
                                    const msgText = `⏱️ *PVP REME ROOM EXPIRED* ⏱️\n\nRoom ${code} telah dihapus karena tidak ada lawan selama 5 menit. Saldo pembuat room telah dikembalikan.`;
                                    if (creatorMention) sendQueue(chat.id._serialized, msgText, { mentions: [creatorMention] }); else sendQueue(chat.id._serialized, msgText);
                                }
                            }, 5 * 60 * 1000);
                            pvpRoomTimeouts.set(code, to);

                            // Build PvP room created message per requested template
                            const creatorMention = ensureSerializedId(registered.uid || registered.number);
                            const createdLines = [];
                            createdLines.push('🎮 *PVP REME ROOM DIBUAT* 🎮\n');
                            createdLines.push(`Mode: REME`);
                            createdLines.push(`Room: ${code}`);
                            createdLines.push(`Bet: ${totalbet}`);
                            createdLines.push(`Ronde: ${ronde}\n`);
                            createdLines.push(`${creatorMention ? `👤 Dibuat oleh: @${creatorMention.split('@')[0]}` : `👤 Dibuat oleh: ${registered.number}`}`);
                            createdLines.push('\nUntuk bergabung ketik:');
                            createdLines.push(`*.pvp reme ${code}*\n`);
                            createdLines.push('⏱️ Room otomatis dihapus dalam 5 menit jika tidak ada lawan');
                            const createdMsg = createdLines.join('\n');
                            if (creatorMention) replyQueue(msg, createdMsg, { mentions: [creatorMention] }, 'high'); else replyQueue(msg, createdMsg, undefined, 'high');
                            return;
                        } finally {
                            try { if (lockAcquired) await DB.releaseLock(lockKey, lockToken); } catch (e) { /* ignore */ }
                        }
                    }

                    replyQueue(msg, '❌ Perintah tidak valid. Mode yang tersedia: reme\n\n*Penggunaan*: .pvp [mode] [kode_room] [bet] [ronde]', undefined, 'high');
                } catch (e) {
                    console.error('Error processing .pvp:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat memproses .pvp', undefined, 'high');
                }
                return;
            }

            // .bal - show balance to the requesting registered user
            if (lower.startsWith('.bal')) {
                try {
                    // Check if there's a mentioned user to inspect
                    const targetObj = await getMentionedTarget(msg, body);
                    if (targetObj && (targetObj.number || targetObj.uid)) {
                        const targetReg = findRegistrationForTarget(targetObj, regs);
                        if (!targetReg) {
                            const display = (targetObj.number || targetObj.uid);
                            replyQueue(msg, `Pengguna ${display} belum teregistrasi.`, undefined, 'high');
                            return;
                        }
                        const bal = Number(targetReg.balance || 0);
                        const maybeId = ensureSerializedId(targetReg.uid || targetReg.number || targetObj.uid || targetObj.number);
                        const formatted = `${formatNumber(bal)} Coin`;
                        if (maybeId) {
                            replyQueue(msg, `💰 Coin @${maybeId.split('@')[0]} saat ini: ${formatted}`, { mentions: [maybeId] }, 'high');
                        } else {
                            replyQueue(msg, `💰 Coin ${targetReg.number} saat ini: ${formatted}`, undefined, 'high');
                        }
                        return;
                    }

                    // No mention — show caller's balance
                    const reg = regs.find(r => r.number === senderNumber);
                    const bal = Number((reg && reg.balance) || 0);
                    const mentionMe = ensureSerializedId((reg && reg.uid) || reg.number || senderNumber);
                    const formattedMe = `${formatNumber(bal)} Coin`;
                    if (mentionMe) {
                        replyQueue(msg, `💰 Coin @${mentionMe.split('@')[0]} saat ini: ${formattedMe}`, { mentions: [mentionMe] }, 'high');
                    } else {
                        replyQueue(msg, `💰 Coin ${senderNumber} saat ini: ${formattedMe}`, undefined, 'high');
                    }
                } catch (e) {
                    console.error('Error during .bal:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat mengecek saldo.', undefined, 'high');
                }
                return;
            }

            // .tfcoin @user amount - transfer coins to another registered user
            if (lower.startsWith('.tfcoin')) {
                try {
                    // mark inflight for this transfer so takeover can detect in-progress transfer
                    const tfmid = (msg && msg.id && msg.id._serialized) ? msg.id._serialized : (`tf:${msg.from}:${Date.now()}`);
                    const tfkey = `inflight:cmd:tfcoin:${tfmid}`;
                    try { await DB.setInflight(tfkey, { instance: INSTANCE_ID, cmd: 'tfcoin', id: tfmid, ts: Date.now(), from: senderNumber, to: targetObj ? (targetObj.number || targetObj.uid) : null, amount }); } catch (e) { /* ignore */ }
                    const startTf = process.hrtime();
                    // support plain-number target in addition to mention
                    let targetObj = await getMentionedTarget(msg, body);
                    const parts = body.split(/\s+/);
                    if ((!targetObj || (!targetObj.number && !targetObj.uid)) && parts.length >= 2) {
                        const maybeToken = parts[1] || '';
                        const digits = String(maybeToken).replace(/[^0-9]/g, '');
                        if (digits) {
                            targetObj = { number: digits };
                            try {
                                const tryUid = `${digits}@c.us`;
                                const contact = await getContactCached(tryUid);
                                if (contact && contact.id && contact.id._serialized) targetObj.uid = contact.id._serialized;
                            } catch (e) { /* ignore */ }
                        }
                    }
                    if (!targetObj || (!targetObj.number && !targetObj.uid)) {
                        replyQueue(msg, '‼️ Format: *.tfcoin [nomor atau @mention] [nominal]*\n\nContoh: .tfcoin 6285..... 5000 atau .tfcoin @mention 5000', undefined, 'high');
                        return;
                    }

                    const targetReg = findRegistrationForTarget(targetObj, regs);
                    if (!targetReg) {
                        const display = (targetObj.number || targetObj.uid);
                        replyQueue(msg, `Tujuan ${display} belum teregistrasi. Transfer gagal.`, undefined, 'high');
                        return;
                    }

                    // parse amount: REQUIRE the amount to be the immediate token
                    // after the target (i.e. parts[2]). This enforces the format
                    // `.tfcoin @user <amount> [note ...]`. If parts[2] is missing or
                    // not a valid amount token, we reject the command.
                    let amount = 0;
                    if (parts.length >= 3) {
                        const a = parseAmountToken(parts[2] || '');
                        if (a && Number.isFinite(a) && a > 0) amount = a;
                    }
                    if (!amount || amount <= 0) {
                        replyQueue(msg, '‼️ Format tidak valid. Gunakan: .tfcoin [nomor atau @mention] [nominal] [opsional: catatan]\nContoh benar: .tfcoin @user 5000 catatan atau .tfcoin 628123456789 1k catatan', undefined, 'high');
                        return;
                    }

                    // Enforce minimal transfer amount
                    if (amount < 1000) {
                        replyQueue(msg, '😮‍💨 Minimal transfer 1000 Coin', undefined, 'high');
                        return;
                    }

                    // prevent transferring to self
                    if (targetReg.number === senderNumber) {
                        replyQueue(msg, 'Tidak dapat mentransfer ke diri sendiri.', undefined, 'high');
                        return;
                    }

                    const senderReg = registered; // already ensured registered above
                    const current = Number(senderReg.balance || 0);
                    // calculate fee (taken from sender separately) but recipient receives full amount
                    const fee = Math.floor(amount * 0.035);
                    const totalCost = amount + fee;
                    if (current < totalCost) {
                        // Show detailed required total and breakdown (amount + fee)
                        const totalNeeded = formatNumber(totalCost);
                        const amt = formatNumber(amount);
                        const feeFmt = formatNumber(fee);
                        replyQueue(msg, `🥱 Saldo tidak cukup! Dibutuhkan *${totalNeeded} Coin* (${amt} + fee ${feeFmt})`, undefined, 'high');
                        return;
                    }

                    // perform atomic transfer via Redis Lua script when possible
                    let balancesAfter = null;
                    try {
                        if (DB && typeof DB.atomicTransfer === 'function') {
                            balancesAfter = await DB.atomicTransfer(senderNumber, targetReg.number, amount, fee);
                        } else {
                            balancesAfter = await withRegistrationsLock(async (regsNow) => {
                                const s = regsNow.find(r => r.number === senderNumber);
                                const t = regsNow.find(r => r.number === targetReg.number);
                                if (!s || !t) {
                                    replyQueue(msg, 'Gagal menemukan registrasi pengirim atau penerima.', undefined, 'high');
                                    return null;
                                }
                                if (Number(s.balance || 0) < totalCost) {
                                    const totalNeeded = formatNumber(totalCost);
                                    const amt = formatNumber(amount);
                                    const feeFmt = formatNumber(fee);
                                    replyQueue(msg, `🥱 Saldo tidak cukup! Dibutuhkan *${totalNeeded} Coin* (${amt} + fee ${feeFmt})`, undefined, 'high');
                                    return null;
                                }
                                s.balance = Number(s.balance || 0) - totalCost;
                                t.balance = Number(t.balance || 0) + amount;
                                return { senderBalance: Number(s.balance || 0), targetBalance: Number(t.balance || 0) };
                            });
                        }
                    } catch (e) {
                        console.error('Transfer operation failed:', e);
                        replyQueue(msg, 'Terjadi kesalahan saat memproses transfer.', undefined, 'high');
                        return;
                    }

                    try { await DB.clearInflight(tfkey); } catch (e) { /* ignore */ }

                    // If the transfer failed (balancesAfter is null), abort further processing
                    if (!balancesAfter) return;

                    // store fee in bank
                    try { addToBank(fee); } catch (e) { console.error('Gagal menyimpan fee ke bank:', e); }

                    // history logging disabled (transfer history persistence removed)
                    // compute elapsed ms for the command
                    const diff = process.hrtime(startTf);
                    const ms = Math.round(diff[0] * 1000 + diff[1] / 1e6);

                    const mentionSender = ensureSerializedId((senderReg && senderReg.uid) || senderReg.number || senderNumber);
                    const mentionTarget = ensureSerializedId((targetReg && targetReg.uid) || targetReg.number);
                    const lines = [];
                    lines.push(`*✈️ Transfer Coin Berhasil!* (${ms}ms)\n`);
                    lines.push(`📤 Pengirim: ${mentionSender ? `@${mentionSender.split('@')[0]}` : senderReg.number}`);
                    lines.push(`📥 Penerima: ${mentionTarget ? `@${mentionTarget.split('@')[0]}` : targetReg.number}`);
                    lines.push(`💸 Jumlah: *${formatNumber(amount)} Coin*`);
                    lines.push(`📊 Fee: *3.5% (${formatNumber(fee)} Coin)*`);
                    // Use realtime balances returned from the locked update when available
                    const realtimeSenderBal = balancesAfter && typeof balancesAfter.senderBalance === 'number' ? balancesAfter.senderBalance : Number(senderReg.balance || 0);
                    const realtimeTargetBal = balancesAfter && typeof balancesAfter.targetBalance === 'number' ? balancesAfter.targetBalance : Number(targetReg.balance || 0);
                    lines.push(`💰 Saldo Anda: *${formatNumber(realtimeSenderBal)} Coin*`);
                    lines.push(`💰 Saldo Penerima: *${formatNumber(realtimeTargetBal)} Coin*`);

                    const mentionArr = [];
                    if (mentionTarget) mentionArr.push(mentionTarget);
                    if (mentionSender && mentionSender !== mentionTarget) mentionArr.push(mentionSender);
                    if (mentionArr.length) replyQueue(msg, lines.join('\n'), { mentions: mentionArr }, 'high'); else replyQueue(msg, lines.join('\n'), undefined, 'high');
                } catch (e) {
                    console.error('Error during tfcoin transfer:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat melakukan transfer.', undefined, 'high');
                }
                return;
            }

            // .kalku simple calculator for registered users
            if (lower.startsWith('.kalku')) {
                try {
                    const expr = body.replace(/^\.kalku\s*/i, '').trim();
                    if (!expr) { replyQueue(msg, '🧌 Ekspresi matematika tidak valid. Contoh: *.kalku 16800/2*4*', undefined, 'high'); return; }
                    // allow only numbers, operators and parentheses
                    if (!/^[0-9+\-*/().\s]+$/.test(expr)) { replyQueue(msg, '🧌 Ekspresi tidak valid. Gunakan hanya angka dan operator + - * / ( )', undefined, 'high'); return; }
                    let result;
                    try {
                        // safe-ish eval
                        // eslint-disable-next-line no-new-func
                        result = Function('return (' + expr + ')')();
                    } catch (e) {
                        replyQueue(msg, '🧌 Ekspresi tidak dapat dihitung. Pastikan format benar.', undefined, 'high');
                        return;
                    }
                    if (typeof result !== 'number' || !isFinite(result)) { replyQueue(msg, 'Hasil tidak valid.', undefined, 'high'); return; }
                    const out = Number.isInteger(result) ? formatNumber(result) : String(result);
                    replyQueue(msg, `🧌 Hasil: *${out}*`, undefined, 'high');
                } catch (e) {
                    console.error('Error in .kalku:', e);
                    replyQueue(msg, '❌ Terjadi kesalahan saat menghitung.', undefined, 'high');
                }
                return;
            }



            // Handle other dot-commands here (placeholder)

            // .cmd - list available commands for registered users
            if (body.toLowerCase() === '.cmd') {
                try {
                    const lines = [];
                    lines.push('📱 *D A F T A R   C O M M A N D* 📱\n');
                    lines.push('📂 *USER*');
                    lines.push('◦ *.bal*');
                    lines.push('   _Menampilkan jumlah saldo yang dimiliki_');
                    lines.push('◦ *.gass*');
                    lines.push('   _Melakukan spin pada roulette_');
                    lines.push('◦ *.kalku*');
                    lines.push('   _Calculator matematika sederhana_');
                    lines.push('◦ *.listadmin*');
                    lines.push('   _Menampilkan daftar admin_');
                    lines.push('◦ *.listqris*');
                    lines.push('   _Menampilkan daftar code QRIS yang tersedia_');
                    lines.push('◦ *.cmd*');
                    lines.push('   _Menampilkan semua command yang tersedia_');
                    lines.push('◦ *.ping*');
                    lines.push('   _Balasan dengan Pong dan latensi dalam ms_');
                    lines.push('◦ *.pvp*');
                    lines.push('   _Bermain PvP (Player vs Player) dengan bet_');
                    lines.push('◦ *.qr*');
                    lines.push('   _Menampilkan QRIS yang tersedia atau QRIS GEMSPIN_');
                    lines.push('◦ *.tfcoin*');
                    lines.push('   _Transfer saldo kepada sesama player_');
                    lines.push('📖 Total Command: 10');
                    replyQueue(msg, lines.join('\n'), undefined, 'low');
                } catch (e) {
                    console.error('Error in .cmd:', e);
                    replyQueue(msg, 'Terjadi kesalahan saat menampilkan daftar command.', undefined, 'low');
                }
                return;
            }
        }

        // Example simple auto-reply in group for registered users (non-dot messages)
        // If you want to require registration for regular messages too, change logic above.
    } finally {
        if (_inflightSet) {
            try { await DB.clearInflight(inflightKey); } catch (e) { /* ignore */ }
        }
    }
});

client.on('ready', () => {
    // Only leader should announce ready and run leader-only timers
    if (!amLeader) return;
    console.log("Bot siap!");
    try { resetIdleClearTimer(); } catch (e) { /* ignore */ }
});

// Periodic heap cleanup to reduce long-running memory growth (e.g. Puppeteer)
// Runs every 5 minutes and logs before/after memory usage when GC is available.
// Note: to enable manual GC, start Node with the `--expose-gc` flag.
{
    const HEAP_CLEAN_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
    if (typeof global.gc === 'function') {
        setInterval(() => {
            try {
                const before = process.memoryUsage();
                // Trigger V8 garbage collection
                global.gc();
                const after = process.memoryUsage();
                const fmt = (v) => `${Math.round(v / 1024 / 1024)}MB`;
                console.log(`[heap-cleanup] GC triggered successfully. rss(before/after): ${fmt(before.rss)}/${fmt(after.rss)}, heapUsed(before/after): ${fmt(before.heapUsed)}/${fmt(after.heapUsed)}`);
            } catch (e) {
                console.error('[heap-cleanup] Error while running GC:', e);
            }
        }, HEAP_CLEAN_INTERVAL_MS).unref();
        console.log('[heap-cleanup] Periodic GC enabled (every 5 minutes).');
    } else {
        console.warn('[heap-cleanup] global.gc() not available. Start Node with `--expose-gc` to enable manual GC.');
    }
}

client.initialize();







